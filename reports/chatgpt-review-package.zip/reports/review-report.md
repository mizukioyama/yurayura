# Review report

## Top section layout update (2026-09-12)

TopページのConcept／Artistsセクションを、既存の文章・画像・スライダー構造・アニメーションを維持したまま調整しました。

### Changes

- `assets/css/top-sections.css` を追加し、`body.top-page` のTopページだけに適用
- Conceptを見出しと本文の2列構成にし、左寄せに偏っていた余白を整理
- Conceptの `Conceptを読む` 導線を本文側に配置
- Artistsの見出し・紹介文を中央に揃え、作品カードを中央の読みやすい幅に整理
- 作品カードの作家名ボタンを全体覆いから小さなラベルへ変更し、作品画像を見える状態に復元
- Viewボタンをカード幅に合わせた最大520px（スマホ最大280px）へ調整
- `slide.js`、既存画像、Gallery、共通ヘッダー／フッターは変更なし

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| 差分空白 | PASS | `git diff --check` |
| JavaScript構文 | PASS | `node --check assets/js/slide.js` |
| Top導線 | PASS | ローカルブラウザAXツリーでConcept導線とGallery導線を確認 |
| Concept配置 | PASS | ローカルブラウザで見出し・本文・導線の2列配置を確認 |
| Artists配置 | PASS | ローカルブラウザで中央寄せ見出し・紹介文・作品画像を確認 |
| 既存ページ保全 | PASS | Top専用CSSとして適用し、Concept／GalleryのCSS・JSは未変更 |

### Review judgment

今回の変更はTopの2セクションに限定した表示調整です。公開後はGitHub PagesのTopをスマートフォン実機でも最終確認してください。

### Public verification update (2026-09-12)

- GitHub Pagesの公開Topをキャッシュ更新URLで再読込し、TopのConcept導線を確認
- 公開ブラウザでArtistsの見出し・紹介文の中央寄せ、作品画像、カード幅内のViewボタンを確認
- 公開ブラウザでTOP / CONCEPT / GALLERYのナビゲーションと既存Galleryリンクを確認
- `git ls-remote origin HEAD` は `5b7e1cd4621c6f1528be1c4658adc2eba607c8e5` と一致

## Current task update (2026-09-12)

既存Topのトーンを維持したConceptページを新規作成し、Topからの導線と3ページ共通ナビを追加しました。既存Galleryの作品一覧、フォーム、FAQ、背景アニメーション、既存画像は変更していません。

### Implemented

- `concept.html` と `assets/css/concept.css` を追加
- Topと同じ紙質背景、霧・揺らぎ演出、縦組み見出し、フォント、余白感、レスポンシブ設計を再利用
- 既存作品画像 `202337.webp` / `202402.webp` をConcept内の視覚要素として使用
- TopのConceptセクションに `Conceptを読む` 導線を追加
- 共通パーツとGalleryのナビを `TOP / CONCEPT / GALLERY` に統一
- 既存ファイルは編集前に `backups/` へ退避

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| JavaScript構文 | PASS | `node --check` で既存アニメーション・メニューJSを確認 |
| 差分空白 | PASS | `git diff --check` |
| Concept DOM | PASS | ローカルブラウザで見出し、本文、画像2点、Gallery導線を確認 |
| Top導線 | PASS | TopのConceptセクション内に `Conceptを読む` を確認 |
| Gallery保全 | PASS | ローカルブラウザで4作品、カテゴリ、ページネーション、3ページナビを確認 |
| レスポンシブCSS | PASS | 480px以下の専用レイアウトと既存clamp設計を確認 |
| 公開先 | PASS | `origin` は `https://github.com/mizukioyama/yurayura.git`、push前HEADを確認 |

### Review judgment

実装とローカル表示確認は完了しています。公開後はGitHub Pagesの `concept.html` とTop/Galleryのナビを実機で最終確認してください。

## Publication update (2026-09-12)

- Commit: `e3ebc34` (`Add dedicated yurayura concept page`)
- Remote: `origin/main` を確認済み
- Public URL: `https://mizukioyama.github.io/yurayura/concept.html`
- Public HTTP response: 200
- 公開ブラウザでConcept本文、作品画像2点、Gallery導線、Top / Concept / Galleryナビを確認

## Clarification update (2026-09-12)

- Conceptページのh2見出しをすべて横書きに変更
- Conceptページのヘッダー／フッターはTopと同じ共通パーツを継続使用
- Conceptページの共通 `menu-style.css` / `main.css` 参照をTopと同じバージョン指定に統一

## Loading animation audit (2026-09-09)

初期表示時の霧ローディングを対象に、通常時の`holdDuration`を550ms、穴の拡大を2600ms、拡大後の保持を300ms、フェードを1400msへ調整しました。合計時間は約3.4秒から約4.85秒へ延長され、動きを緩やかにしています。`prefers-reduced-motion`時の短縮設定と、その他のアニメーション・JavaScriptは変更していません。CSS／JSのキャッシュバスターも更新しました。

## Scope

- Target: Concept、Artists、Contact、FAQ、Access の見出し・本文、フォーム文言、ヘッダー／フッター文字、Artistsスライドショーのgallery.htmlリンク、gallery.htmlのカテゴリ・カード・ページネーション
- Non-target: Artists以外のHTML本文・構造、フォーム送信処理、既存の背景アニメーション・FAQ動作・ボタン実装
- Recovery copy: `backups/` 内の作業前コピー（commit対象外）

## Change

指定された文章へ差し替え、既存の `pc-br` の仕組みを維持しました。Concept 内の改行タグはすべて `<br class="pc-br" />` に統一しています。

対象範囲の見出し・本文・FAQ・Access・フォーム文言を横書き・左寄せに統一しました。本文は `--responsive-copy-size`、見出し・UI文字は見出し用の `clamp()` を使用しています。h1、h2、h3、小見出し、モーダル、送信ボタン、ヘッダー／フッター文字まで、画面幅に応じて最小値・最大値の間で変化します。

参照リポジトリの `src/gallery.html`、`src/style/gallery.css`、`src/style/sidebar.css`、`src/public/gallery-sidebar.html` を確認し、見出し・左側カテゴリ・半透明の作品パネル・画像付きカード一覧・ページラインの構成を `gallery.html` / `gallery.css` に反映しました。Artistsの背景画像非表示は維持し、`index.html` の既存スライドショー構造は変更していません。

フォームの問い合わせ種別4項目は、既存のHTML順序を維持したまま `contact-check-grid` を2列のCSS Gridへ変更し、列・行位置も明示して2段で表示するようにしました。フォームCSSにはキャッシュバスターを付け、古いレイアウトの残存を防いでいます。フォーム送信処理とチェックボックス検証は変更していません。

FVを除く全`section`（body内各セクション）の左右Paddingを44pxに統一しました。FVは既存レイアウトを維持するため左右0pxとし、ArtistsのスライドショーとView背景の相殺値も44pxへ同期しています。

Q&Aの`.faq-box`内側10pxを解除し、Contact・Q&A・Accessの内容左右位置を揃えました。

FAQの`faq.js`を、確実な初期化・開閉状態の同期・`aria-expanded`/`aria-controls`設定に対応させました。「期間と場所と時間」「アクセス」などの外側の分類は通常の見出しとし、回答内の「展示期間」「発送について」「領収書について」などをアコーディオンにしました。質問順は展示概要、アクセス、販売作品・グッズ、購入、主催者の自然な順に整理しました。

外側の見出しは元のFAQ質問と同じ背景画像・内側の境界表現を維持しました。

FV以外の全`section`は固定の`100vh`を解除して`height: auto; min-height: 0`とし、内容量と既存paddingに応じた自然な高さにしました。FVだけは`height: 100vh; min-height: 100vh`を維持しています。

スマホ幅ではFV以外の上下paddingを`clamp(72px, calc(7vw + 48px), 96px)`に調整し、従来の120〜128px相当の余白による過度な縦長化を抑えました。

Concept/Artistsはさらに上下paddingをデスクトップで`clamp(56px, calc(3vw + 32px), 80px)`、スマホで`clamp(48px, calc(5vw + 32px), 72px)`に調整しました。Artistsの`artists-bg.webp`背景コンテナは非表示にし、既存スライドショーを表示しています。

Conceptは展示コンセプトに合わせ、上記共通値より大幅に広い上下paddingをデスクトップで`clamp(112px, calc(6vw + 80px), 176px)`、スマホで`clamp(96px, calc(8vw + 80px), 160px)`に設定しました。

未反映対策として、`index.html`の`main.css`読み込みに`v=20260909-slider-external-gallery`を付け、ブラウザキャッシュで旧CSSが残らないようにしました。

Footerのリンククラスを`header-link`から`footer-link`へ分離し、Headerと同じ文字間隔（PC`0.8rem`、スマホ`0.2rem`）を明示しました。`menu-style.css`にもキャッシュバスターを付けています。

ギャラリーページは参照元と同じ `gallery-containt` → `content` → `.work` → `.work-img` の構造に変更しました。作品は1件ごとの横配置、スマホでは縦積みとし、1ページ10件を基準に作品数からページボタンを自動生成します。画像ファイルの差し替えは行っていません。

`gallery.html` を実際の作家紹介ページとして整備し、作家・ジャンルのカテゴリ絞り込み、4作品の `.work` レイアウト、`#mizuki-01`〜`#mizuki-04` のアンカーを追加しました。既存画像はそのまま使用し、ジャンルはDigitalとして登録しています。作品は10件を1ページ単位として、`gallery.js`が作品数からページ数を自動生成します。Artistsの既存スライド内Mizukiカード4件とViewボタンは、指定された `https://mizukioyama.github.io/yurayura/gallery.html` へリンクします。

## Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Concept本文の一致 | PASS | ブラウザDOMで指定文と完全一致 |
| `br` 構造 | PASS | Concept内11個、無効タグ0個、全て `pc-br` |
| HTMLのブラウザ解釈 | PASS | localhostで `document.readyState=complete`、対象要素を取得 |
| Tidy構文確認 | PASS / 注意あり | 対象変更箇所に新規エラーなし。既存HTML5要素等の警告は Known Issues に記録 |
| 対象テキスト表示 | PASS | Concept、Artists、Contact、FAQ、Access、フォーム文言が `writing-mode: horizontal-tb`、左寄せ |
| 見出しサイズ | PASS | h1、h2、h3、小見出しが `clamp()` の計算値で表示 |
| ブレイクポイント | PENDING | CSSは4帯へ整理済み。今回の変更後の画面境界確認はMacロック中のため未完了 |
| フォントサイズ | PASS | 本文320px:12.4px、390px:13.9px、480px以上:最大14px。h2は18〜28px、h3は14〜20pxの範囲 |
| レスポンシブ表示 | PENDING | 変更前の確認記録はあるが、今回のCSS変更後の画面確認は未完了 |
| Artistsスライダー | PASS | `memberSlider`/`memberTrack`と既存`slide.js`を維持。Mizukiカード4件のリンク先だけ指定URLへ変更 |
| gallery.html | PASS | Art Index、左側カテゴリ、`gallery-containt` / `content` / `.work` 構造、4作品、`#mizuki-01`〜`#mizuki-04`を確認。画像ファイルは変更なし |
| カテゴリ | PASS | 作家「Mizuki」、ジャンル「Digital」の絞り込みUIとARIA状態同期を確認 |
| ページネーション | PASS | `pageSize=10`、作品数から`Math.ceil(filteredCards.length / pageSize)`でページ数を生成する実装を確認。参照元同様の1作品1行レイアウト |
| Mizuki / Viewリンク | PASS | indexの4カードとViewボタンが`https://mizukioyama.github.io/yurayura/gallery.html`を指定 |
| Viewボタン背景幅 | PASS | 既存の深緑背景・fluid指定・レスポンシブ幅ルールは変更していない |
| JavaScript console error | PASS | 表示確認時の error 0件 |
| FAQアコーディオン | PASS | 外側の分類は`.faq-heading`、回答内の`.faq-sub-question`をJSで開閉し、`is-open`とARIA状態を同期。同時に複数項目を開かない |
| セクション高さ | PASS | FV以外は`height:auto; min-height:0`、FVは`100vh`。既存のpadding・コンテンツ構造は維持 |
| スマホsection高さ | PASS | 320〜699pxでFV以外の上下paddingを72〜96pxへレスポンシブ調整。FVは100vhのまま |
| Concept/Artists高さと背景 | PASS | 両sectionの上下paddingを個別に縮小し、Artists背景画像だけを非表示。スライドショーを維持 |
| CSS反映 | PASS | `main.css?v=20260909-responsive-breakpoints`で今回のCSSを読み込む設定を確認 |
| Header/Footer文字間隔 | PASS | Footerリンクを`footer-link`へ統一し、Headerと同じPC/スマホの`letter-spacing`を適用 |
| フォームチェックボックス | PASS | 320/390/699/700/1024pxで問い合わせ種別4項目が2列2段。HTML順序、選択状態、必須検証は維持 |
| FVを除く全section左右Padding | PASS | 320/390/699/700/1024/1440pxでConcept/Artists/Contact/FAQ/Accessの左右44px、FVは左右0px。bodyの横スクロールなし |
| Contact・Q&A・Accessの左右余白 | PASS | Q&Aの`.faq-box`内側paddingを0pxにし、3セクションの内容位置を統一 |
| 差分範囲 | PASS | 今回の追加差分は `index.html` のArtistsリンク、`gallery.html` の作家紹介ページ化、レビュー資料、作業前バックアップ。フォーム・FAQ・既存JSは変更なし |

## Judgment

実装・静的検証を完了しました。参照リポジトリ側のギャラリーレイアウトは今回の対象外として保留しています。

## Responsive breakpoint audit (2026-09-09)

今回の追加監査で、従来のCSSには `320〜699px` と `700〜1239px` の境界が残っており、指定された4区分と一致していないことを確認しました。以下を修正しました。

- `〜375px`、`376〜480px`、`481〜1335px`、`1336px〜` の4区分をレスポンシブ設計の基準に統一
- 旧 `699px` 境界を `480px` 境界へ整理
- `section`、`section__inner`、カード、フォーム、Accessの地図・情報欄の最小幅／最大幅を調整
- スマホ幅の地図を幅100%にし、Viewボタンの既存の280px／480〜520pxルールを維持
- `slide.js`、`faq.js`、`form.js`、`allmenu.js`は変更せず、CSS読み込みのキャッシュバスターのみ更新

タブレット幅では、共通sectionの上下余白を`64〜96px`、Conceptを`96〜144px`、Artistsを`64〜104px`、Contact／FAQ／Accessを`72〜120px`で補間します。Artistsカードは`220〜320px`、Viewボタンは`360〜520px`、地図は内側幅に合わせて最大740px相当、フォームの入力欄と送信欄は狭いタブレットでも折り返せる設定にしました。Accessの駅情報と詳細情報は、幅に応じて2列／自動調整グリッドになります。

静的検証では、旧 `699px`／`1239px` の有効なメディアクエリが残っていないこと、JavaScript構文、差分空白を確認しました。HTMLの `tidy` は既存のHTML5要素と `&display` 表記に関する警告を継続して出力します。また、Access内の既存の `</wbr>` は今回の対象外として変更していません。

Macがロック中で、ブラウザのヘッドレス起動も終了したため、今回のCSS変更後の実機・ブラウザ画面確認は未完了です。そのため、commit / pushは表示確認後まで保留しています。復元用コピーはローカルの `backups/` に保持し、commit対象から除外します。

## Figma gallery frame implementation (2026-09-09)

ユーザー共有のFigma作家紹介フレーム（デスクトップ `18:1600`、モバイル `607:291`）を基準に、`gallery.html`のページ形状を更新しました。Figmaの一時アセットURLはコミット用コードへ持ち込まず、既存ローカル画像と既存機能を維持しています。

- ヒーローを「作家紹介」とし、白い半透明・ぼかし背景、PC中央配置、スマホ左寄せを実装
- ヒーロー下に紹介文とジャンル情報を追加
- PCは作品画像を2列、スマホは1列にし、PC画像幅340px／スマホ画像246×320pxを基準にレスポンシブ化
- 作品下のタイトル・作家情報、Figmaの余白感、Akaya Kanadakaのページ番号表記（`1P`）を反映
- 作家・ジャンル絞り込み、既存4作品、作品数連動のページングは維持
- Zen Maru Gothicを追加し、`gallery.css`のページ固有オーバーライドとして実装
- 編集前に`backups/gallery.html.before-figma-frame-20260909.html`、`backups/gallery.css.before-figma-frame-20260909.css`、`backups/gallery.js.before-figma-frame-20260909.js`を作成

### Verification update

| Check | Result | Evidence |
| --- | --- | --- |
| HTMLタグ構造 | PASS | 自作タグスタック検査で`HTML_TAG_STACK_OK` |
| `br`タグ | PASS | 4箇所すべて`<br />`の正しい空要素 |
| JavaScript構文 | PASS | `node --check assets/js/gallery.js` |
| PC表示 | PASS | ローカルブラウザでヒーロー、2列カード、メタ情報、1P、フッターを目視確認 |
| スマホ相当表示 | PASS | ローカルブラウザで左寄せタイトル、1列カード、246×320px画像、メタ情報を目視確認 |
| 絞り込み・ページングDOM | PASS | Category、作家／ジャンルボタン、`galleryPagination`、`1ページ目を表示`を確認 |
| index.htmlスライドショー | NOT TOUCHED | 今回の変更対象外 |
| 公開URL | NOT TESTED | 公開・pushはこの作業では実行していない |

## Top layout rollback (2026-09-12)

### Scope

公開 `mizukioyama/yurayura` の `main` を基点に、軽量化コミット `c90eeef654916011c34c120baf25055757381885` が追加したTop専用CSSの作品JPEG背景指定4件だけを除去しました。Concept / Gallery の後続修正は維持しています。

### Changes

- `assets/css/top-sections.css`: c90eeefの17行追加分を削除
- `index.html`: `top-sections.css` のキャッシュバスターを `v=20260912-top-sections-rollback` へ更新
- 編集前のCSSとindexを `backups/20260912_before_top_layout_rollback/` に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| 正常時点CSS一致 | PASS | 作業後blob `9822daa41968281a66bfcedc39da329ba6ea91e9` が `28f69fc:assets/css/top-sections.css` と一致 |
| c90差分限定 | PASS | c90eeefはTop CSSの17行追加のみ。今回その逆差分を適用 |
| 差分空白 | PASS | `git diff --check` |
| Concept / Gallery保全 | PASS | `concept.html` / `gallery.html` と関連CSS・JSは未変更 |
| JavaScript構文 | PASS | `node --check assets/js/slide.js`、`node --check assets/js/gallery.js` |
| 公開main基点 | PASS | `origin/main` は `b92d12b5c49b494512ce3fa23b60f773dab22d7b` |
| 公開Topレイアウト | PASS | 公開Topでrollback版CSS、JPEG上書きなし、カード8件、横スクロールなし、Concept / Gallery導線を確認 |

### Judgment

Topのレイアウト変更原因に対する最小の巻き戻しです。公開Topの作品カード、Concept、Artists、3ページ導線を確認済みです。公開Concept / Galleryも表示・導線・横スクロールなしを確認しました。

## Top historical composition restore (2026-09-12)

### Root cause

前回の画像差し替え分を戻しても、`main.css` に残る全体向けレスポンシブ規則と `top-sections.css` のレイアウト上書きがTopへ適用され続けていました。そのため、Concept／Artistsが横組み・中央寄せの構成になり、Artistsのカードが一枚の大きな表示になっていました。

### Changes

- `assets/css/top-sections.css` は28f69fc時点の内容を保持し、c90eeefのJPEG背景指定も戻した状態を維持
- `assets/css/top-legacy.css` を追加し、Topだけに以前の縦組み、100vhセクション、420×280pxカード、15px間隔の連続スライダーを適用
- `index.html` はTop専用復元CSSのキャッシュバスターを追加し、`top-page`スコープを復元
- Concept / GalleryのHTML・CSS・JSは変更なし
- 編集前コピーは `backups/20260912_before_top_layout_restore/` に保持

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Historical Top CSS | PASS | `top-sections.css` が28f69fc時点のblobと一致 |
| Top-only scope | PASS | 復元CSSの全セレクタを `.top-page` 配下に限定 |
| Local visual layout | PASS | Concept縦組み、Artists縦組み、連続カード、背景表示をブラウザで確認 |
| Static checks | PASS | `git diff --check`、`node --check assets/js/slide.js`、`node --check assets/js/gallery.js` |
| Concept / Gallery source preservation | PASS | 対象ページと関連CSS・JSに差分なし |
| Public deployment | PASS | `main` の `2397dd1` を公開ブラウザで確認。Top、Concept、Galleryを再読込 |

### Judgment

Topの表示崩れに対して、共有ページへ波及しない復元用CSSで以前の構成へ戻しました。公開Topの縦組み・複数カード表示、公開Concept / Galleryの表示を確認し、今回の復元を完了とします。

## Header / Footer restoration (2026-09-12)

### Scope

TopのHeader表示状態と共通Footerの構造だけを確認・復元しました。Concept本体には着手していません。

### Changes

- `assets/js/allmenu.js` を以前の動作へ戻し、デスクトップではスクロール後もHeader本体を表示
- 縮小メニューは320〜699pxのスマートフォンで、1画面分スクロールした場合だけ有効化
- `assets/parts/header.html` / `assets/parts/footer.html` は28f69fc時点と一致しているため変更なし
- 作業前コピーを `backups/20260912_before_header_footer_restore/` に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Desktop header | PASS | ローカルブラウザでスクロール後も左側の縦型Headerを確認 |
| Footer | PASS | ローカルブラウザで中央の縦型Footerナビとコピーを確認 |
| JavaScript | PASS | `node --check assets/js/allmenu.js`、ブラウザエラー0件 |
| Concept body untouched | PASS | Concept本文・構造・関連CSS・JSに差分なし（読み込みURLの更新のみ） |
| Public deployment | PASS | push後の公開Topを再読込し、左側の縦型Header、中央のFooter、公開ブラウザのエラー0件を確認 |

### Public verification

- 公開URL `https://mizukioyama.github.io/yurayura/index.html` を再読込して確認
- デスクトップ表示でHeader本体の `TOP / CONCEPT / GALLERY` が左側に表示され、＋ボタンだけにならないことを確認
- ページ末尾でFooterの中央縦型ナビとコピーライトを確認
- 公開ブラウザのコンソールエラーは0件

## Top label correction (2026-09-12)

### Scope

共通Header / Footerの日本語ラベルだけを、指定どおり`トップページ`から`トップ`へ変更しました。Concept / Galleryのラベル、本文、リンク先、縦書き、左右順は維持しています。

### Changes

- Header / Footerの表示ラベルとaria-labelを`トップ`へ変更
- `CONCEPT / 世界観`、`GALLERY / 作品`は変更なし
- 各リンクの英語名＋日本語説明が1つの選択・クリック範囲になる構成を維持
- 左から`TOP → CONCEPT → GALLERY`の表示順を維持
- キャッシュバスターを`20260912-nav-top`へ更新
- 編集前コピーを`backups/20260912_before_top_label_update/`に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| ラベル | PASS | ローカルDOMでHeader / Footerの日本語ラベルが`トップ`、`世界観`、`作品`であることを確認 |
| 縦書き | PASS | 6リンクすべて`writing-mode: vertical-rl`を維持 |
| 左右順 | PASS | Header / Footerともに左から`TOP → CONCEPT → GALLERY`を確認 |
| 選択範囲 | PASS | 6リンクすべて`inline-block`で英語名＋日本語説明を包含 |
| Concept / Gallery保全 | PASS | 本文・構造・関連CSS・JSは変更せず、共通読み込みURLのみ更新 |

### Public verification

- `main`へのpushは`fc50724`で成功
- 公開TopのアクセシビリティツリーでHeader / Footerの表示が`トップ`、`世界観`、`作品`へ更新されたことを確認
- 公開Topの本文、Concept導線、Gallery導線が表示され、既存構成が維持されていることを確認
- 公開ブラウザ上の確認URLは`nav-top-verify-20260912-r4`

## Header / Footer label alignment (2026-09-12)

### Scope

Header / Footerのナビ項目だけを対象に、英語ラベル・日本語ラベルの開始位置と区切り線の位置・高さを共通化しました。Top / Concept / Galleryの本文とリンク先は変更していません。

### Changes

- 3項目すべてのリンク領域を共通高さに固定し、デスクトップ371px、スマートフォン220pxへ調整
- 英語ラベルと日本語ラベルを個別要素として同じ基準位置に配置
- 区切り線を共通位置へ配置し、高さをデスクトップ30px、スマートフォン15pxで統一
- 英語名＋日本語説明が1つの選択・クリック範囲になる構成を維持
- 編集前コピーを`backups/20260912_before_nav_alignment_update/`に保存

### Local verification

| Check | Result | Evidence |
| --- | --- | --- |
| 文字の開始位置 | PASS | Header / Footerの6リンクで英語Y座標と日本語Y座標がそれぞれ一致 |
| リンク領域の高さ | PASS | 6リンクすべて371px（デスクトップ相当） |
| 線の位置・高さ | PASS | 6本すべて同一基準位置・高さ30px |
| 既存導線 | PASS | `TOP / トップ`、`CONCEPT / 世界観`、`GALLERY / 作品`のhrefを維持 |
| ブラウザエラー | PASS | ローカルブラウザのエラー0件 |

### Public verification

- `main`への反映後、公開Topの一意URLで最終配置を確認する

## Header link interaction fix (2026-09-12)

### Scope

Headerのリンククリックだけを復旧しました。Headerの親要素に設定されていた`pointer-events: none`は維持し、実際のHeader / Footerリンクへ`pointer-events: auto`を設定しています。

### Changes

- `.header-link, .footer-link`をクリック可能に復旧
- `allmenu.js`のパーツ取得バージョンを`20260912-nav-link-fix`へ更新
- `index.html` / `concept.html`の共通ナビ読み込みキャッシュバスターを更新
- 編集前コピーを`backups/20260912_before_header_link_fix/`に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| クリック受付 | PASS | Headerリンクの実効`pointer-events`が`auto`になったことを確認 |
| Header遷移 | PASS | ローカルHeaderの「世界観」をクリックし、`concept.html`へ遷移 |
| ラベル整列 | PASS | 縦書き、文字位置、線位置・高さの整列を維持 |
| Top / Concept / Gallery保全 | PASS | 本文と既存hrefは変更なし |
| ブラウザエラー | PASS | 遷移後のローカルブラウザでエラー0件 |

### Public verification

- 公開Topをキャッシュ更新URLで再読込し、Headerの `トップ` / `世界観` / `作品` と既存のhrefを確認
- 公開TopのHeader「世界観」をクリックし、公開 `concept.html` へ遷移することを確認
- スマートフォン実機での物理タップは未確認

## Navigation label update (2026-09-12)

### Scope

Header / Footerの共通ナビだけを対象に、英語名と日本語説明の表記を指定どおりに統一しました。Top・Concept本文、Gallery本文、リンク先は変更していません。

### Changes

- `Home` を `トップページ` に変更
- `TOP / トップページ`、`CONCEPT / 世界観`、`GALLERY / 作品` の組み合わせに統一
- 既存の `writing-mode: vertical-rl` を維持し、各リンクを `inline-block` 化して英語名から日本語説明までを1つの選択・クリック範囲に設定
- 縦書きの表示順を左から `TOP → CONCEPT → GALLERY`（トップ → 世界観 → 作品）に調整
- `index.html` / `concept.html` のCSS・JSキャッシュバスターと、動的パーツ取得URLを更新して公開環境の古いラベル残りを防止
- 編集前コピーを `backups/20260912_before_nav_label_update/` に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| ナビ文言 | PASS | ローカルDOMで3項目の表示名を確認 |
| 縦書き | PASS | 6リンクすべて `writing-mode: vertical-rl` |
| 左右順 | PASS | Header / Footerともに左から `TOP → CONCEPT → GALLERY` の矩形位置を確認 |
| 選択範囲 | PASS | 各英語名＋日本語説明が1つの `inline-block` リンク範囲 |
| Concept / Gallery保全 | PASS | 本文・構造・関連CSS・JSに差分なし（`index.html` / `concept.html` は読み込みURLのみ更新） |

### Public verification

- 公開Topをキャッシュ更新URLで再読込し、3項目の日本語ラベルが更新されていることを確認
- 公開Topのスクリーンショットで、英語名と日本語説明が縦書きで表示されることを確認
- 公開Topのスクリーンショットで、左から `TOP → CONCEPT → GALLERY` の順を確認
- 公開TopのDOMで左座標が `トップページ → 世界観 → 作品` の順になることを確認
- 公開ブラウザのコンソールエラーは0件

## Artists section correction (2026-09-12)

### Scope

Topページの作品（Artists）セクションだけを対象に、見出し直下の説明文とViewボタンの幅を調整しました。背景画像・背景色・カード表示・Concept / Galleryは変更していません。

### Changes

- `assets/css/top-artists.css` を追加し、作品セクションの説明文を横書き・中央寄せに統一
- 説明文の最大幅を520px、スマートフォンではセクション内100%に設定
- Viewボタンの外枠をデスクトップ最大520px、スマートフォン最大280pxへ調整し、中央配置を維持
- 作品セクションの既存背景指定は変更せず、Topページだけで読み込む構成に限定
- 編集前コピーを `backups/20260912_before_artists_section_fix/` に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| 説明文 | PASS | ローカルブラウザで `writing-mode: horizontal-tb`、`text-align: center`、幅520pxを確認 |
| Viewボタン | PASS | ローカルブラウザで幅520px、中央配置を確認 |
| 背景維持 | PASS | 作品セクションの背景画像URLが変更前と同じであることを確認 |
| 横はみ出し | PASS | ローカル表示で `scrollWidth` と `clientWidth` が一致 |
| 他ページ保全 | PASS | 追加CSSは `.top-page .section--artists` と `#artists` に限定 |

### Public verification

- 公開Topで `top-artists.css?v=20260912-top-artists-center` の読み込みを確認
- 公開Topで説明文の横書き・中央寄せ、幅520pxを確認
- 公開TopでViewボタンの幅520px、中央配置を確認
- 公開Topで背景URLが既存の `assets/img/bg-img.webp` のままであることを確認
- 公開Concept / Galleryでは `top-artists.css` が読み込まれていないことを確認
- スマートフォン実機での最終受入確認は未実施

## Artists full-width backgrounds (2026-09-12)

### Scope

作品セクションのボタン背景帯とスライドショー表示領域を、セクション左右余白の外側まで広げ、画面幅100%に合わせました。説明文の中央寄せ、カード内容、既存背景画像は維持しています。

### Changes

- `assets/css/top-artists.css` でボタン背景帯を画面幅いっぱいに設定
- `assets/css/top-artists.css` でスライドショー表示領域を画面幅いっぱいに設定
- ボタン本体はデスクトップ520px、スマートフォン280pxの中央配置を維持
- 編集前コピーを `backups/20260912_before_artists_full_width_fix/` に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| ボタン背景帯 | PASS | ローカル表示で作品セクションの左端・右端が画面表示領域に一致 |
| スライドショー | PASS | ローカル表示でスライドショーの左端・右端が画面表示領域に一致 |
| 背景維持 | PASS | 既存 `btn-bg-img.webp` と `bg-img.webp` の指定を維持 |
| 横はみ出し | PASS | ローカル表示で `scrollWidth` と `clientWidth` が一致 |
| 公開Top | PASS | 公開Topでボタン背景帯・スライドショーとも画面幅1702pxに一致することを確認 |

### Public verification

- 公開Topで `top-artists.css?v=20260912-top-artists-full-width` の読み込みを確認
- ボタン背景帯とスライドショーの表示領域が、公開表示領域の左右端（1702px）に一致
- ボタン背景画像が既存の `btn-bg-img.webp` のままであることを確認
- 説明文の中央寄せと横書き表示を維持
- 公開Topで横スクロールなしを確認

## Header scroll collapse restoration (2026-09-12)

### Scope

Header JSに残っていたスクロール連動の縮小処理を、PC・モバイル共通で画面高の60％地点から動作するよう復旧しました。Header / Footerの構造、ナビゲーション文言、リンク先、Topの既存レイアウトは維持しています。

### Cause and changes

- 現行JSはモバイル以外で`is-compact`を解除しており、PCでは縮小処理が無効でした
- 判定位置が画面高100％になっていたため、60％へ変更しました
- スクロール処理を`requestAnimationFrame`でまとめ、画面サイズ変更時にも再判定するようにしました
- 縮小状態でのみメニューを開けるようにし、ページ上部へ戻るとHeaderを再表示します
- `index.html` / `concept.html`のJSキャッシュバスターを更新しました
- 編集前コピーを`backups/20260912_before_header_scroll_restore/`に保存しました

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| 60％判定 | PASS | ローカル表示のviewport高720pxで閾値432pxを確認し、scrollY720pxで`is-compact`を確認 |
| Header縮小 | PASS | 閾値超過時にHeader文字が縮小・非表示となり、メニューボタンが表示されることを確認 |
| Header再表示 | PASS | ページ上部へ戻した際に`is-compact`解除、Header一覧表示、メニューボタン非表示を確認 |
| 既存導線 | PASS | Headerリンクの既存クリック修正を維持 |
| Concept / Gallery保全 | PASS | Gallery本体は変更せず、ConceptはJSキャッシュバスターのみ更新 |
| 公開Top | PASS | 公開Topで新JSを読み込み、60％閾値で縮小・上部復帰を確認 |

### Public verification

- `main`のコミット`49ab314`反映後、公開Topで`allmenu.js?v=20260912-header-scroll-60`の読み込みを確認
- 公開Topのviewport高929px、閾値557.4pxで、scrollY929px時に`is-compact=true`・メニューボタン表示を確認
- 公開TopをscrollY0pxへ戻し、アニメーション完了後に`is-compact=false`・Header一覧表示・メニューボタン非表示を確認
- 公開Topで横スクロールなし、Top本文と既存ナビゲーションを確認
- スマートフォン実機でのタップ・表示確認は未実施です

## Shared Header unification and exhibitor alignment (2026-09-12)

### Scope

Top / Conceptで使用している共通HeaderをGalleryにも適用し、3ページのHeader構成・固定位置・縦書きナビ・ラベル表示を統一しました。Topの作品セクションでは「出展者紹介」を中央揃えにしました。

### Changes

- Galleryの独自横長Headerを削除し、`assets/parts/header.html`を動的に読み込む共通Headerへ統一
- Galleryに`menu-style.css`と`allmenu.js`を追加し、60％スクロール時の縮小・メニュー動作を共通化
- Galleryの既存スタイル上書きにより発生していたHeaderの上端・全幅化を解除し、Top / Conceptと同じ固定位置へ調整
- Topの「出展者紹介」を中央配置するTop専用CSSを追加
- 編集前コピーを`backups/20260912_before_gallery_header_unification/`に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Header構造 | PASS | ローカルGalleryで共通Headerの3リンク、日本語ラベル、メニューボタンを確認 |
| Headerレイアウト | PASS | Top / Galleryで固定位置、縦書き、Header左位置76.8px・上位置44.8pxが一致 |
| 出展者紹介 | PASS | Topで見出し内の「出展者紹介」中央がviewport中央636pxと一致（viewport中央640px、丸め差） |
| Gallery保全 | PASS | 作家紹介見出し、4作品、既存フィルター、横はみ出しなしを確認 |
| JavaScript / 差分 | PASS | `node --check assets/js/allmenu.js`、`git diff --check`を通過 |
| 公開反映 | PASS | 公開Top / Concept / Galleryで共通HeaderとTopの中央揃えを確認 |

### Public verification

- `main`のコミット`c5127ac`反映後、公開Top / Concept / Galleryで`allmenu.js?v=20260912-header-unified`の読み込みを確認
- 公開3ページでHeaderの3リンク、共通日本語ラベル、縦書き表示を確認
- 公開Topで「出展者紹介」の中央位置がviewport中央851pxと一致（viewport中央855px、丸め差）することを確認
- 公開GalleryでHeader固定表示、4作品、横はみ出しなしを確認
- スマートフォン実機での表示・タップ確認は未実施です

## Hamburger menu layout correction (2026-09-12)

### Scope

ハンバーガーメニューの展開時だけ通常Headerと異なっていた余白・列間隔・文字間隔・区切り線を、常時表示Headerと同じ構成へ統一しました。Top / Concept / Galleryの既存リンク先と本文は変更していません。

### Changes

- 展開メニューを通常Headerと同じ3列・同じリンク寸法へ統一
- 左から `TOP → CONCEPT → GALLERY` の順、縦書き、`トップ / 世界観 / 作品`を維持
- タブレット幅用`main.css`の後勝ち指定も修正し、CSSの上書きによる再発を防止
- 3ページのCSS / JSキャッシュバスターを更新
- 編集前コピーを`backups/20260912_before_hamburger_menu_fix/`に保存

### Local verification

| Check | Result | Evidence |
| --- | --- | --- |
| 展開レイアウト | PASS | 3ページで縦書き、`gap:40px`、`padding:0`、同一リンク寸法を確認 |
| 順序・文言 | PASS | `TOP / トップ`、`CONCEPT / 世界観`、`GALLERY / 作品`を確認 |
| 開閉 | PASS | 3ページで`aria-expanded`と`is-menu-open`の切替を確認 |
| リンク遷移 | PASS | 展開中のConceptリンクで`concept.html`への遷移を確認 |
| 横はみ出し | PASS | 3ページで横スクロールなしを確認 |
| 静的確認 | PASS | `node --check assets/js/allmenu.js`、`git diff --check` |

### Public verification

- `main`のコミット`d9d2c13`反映後、公開Top / Concept / Galleryで新しいCSS / JSキャッシュバスターの読み込みを確認
- 公開3ページで展開時の`gap:40px`、`padding:0`、縦書き、3リンクの順序・文言を確認
- 公開3ページでハンバーガー開閉、`aria-expanded`、スクロールロック、横はみ出しなしを確認
- 公開Topの検証後は通常表示へ戻した
- スマートフォン実機での表示・タップ確認は未実施

## H2 centering and goods FAQ removal (2026-09-12)

### Scope

Top / Concept / Galleryのすべての`h2`を中央寄せへ統一し、TopのQ&Aからグッズ・ECサイト関連の項目一式を削除しました。その他のFAQ項目、購入方法・発送・領収書の項目は維持しています。

### Changes

- レスポンシブCSSとページ固有CSSの左寄せ上書きを解除し、全`h2`を中央寄せに設定
- Galleryの作家・ジャンル見出しと作品見出しも中央寄せに設定
- Q&Aの「販売する作品、グッズ（購入場所について）」項目を削除
- キャッシュバスターを更新
- 編集前コピーを`backups/20260912_before_h2_center_goods_faq_removal/`に保存

### Local verification

| Check | Result | Evidence |
| --- | --- | --- |
| h2中央寄せ | PASS | Top 4件、Concept 3件、Gallery 6件の計13件で`text-align:center`を確認 |
| グッズFAQ削除 | PASS | グッズ、購入場所、ECサイト関連の表示がなく、FAQ見出しは4件を確認 |
| FAQ保全 | PASS | 期間・アクセス・購入・主催者のFAQを確認 |
| 横はみ出し | PASS | 3ページで横スクロールなしを確認 |

### Public verification

- `main`のコミット`a7d6d99`反映後、公開Top / Concept / Galleryで新しいCSSキャッシュバスターの読み込みを確認
- 公開Topで全`h2`の中央寄せ、グッズ・購入場所・ECサイト関連の非表示、残り4件のFAQを確認
- 公開Concept / Galleryで全`h2`の中央寄せ、共通Header、横はみ出しなしを確認
- 公開Topの検証後は通常表示へ戻した
- スマートフォン実機での表示確認は未実施

## FAQ title and answer revision (2026-09-12)

### Scope

Topの「よくある質問」を中央寄せにし、サイト内に既にある会場・開催・購入情報を基に回答を整理しました。グッズ関連FAQは追加せず、既存の購入FAQは作品購入に関する内容として維持しています。

### Changes

- 「よくある質問」の見出しを中央寄せに固定
- アクセスFAQへ、サイト内の会場住所を追加
- 開催時間、購入方法、支払い、発送、領収書、企画背景の回答を読みやすく修正
- 「下記From」を「下記フォーム」へ修正
- 編集前コピーを`backups/20260912_before_faq_copy_and_title_fix/`に保存

### Local verification

| Check | Result | Evidence |
| --- | --- | --- |
| FAQ見出し | PASS | `よくある質問`の`text-align:center`を確認 |
| FAQ構成 | PASS | 4分類、11項目の回答を確認 |
| 追加情報 | PASS | 会場住所をアクセスFAQへ追加し、Access欄の既存情報と一致 |
| 回答文 | PASS | 誤字修正と開催・購入関連回答の表示を確認 |
| 既存内容 | PASS | グッズFAQなし、購入方法・発送・領収書FAQを維持 |
| 横はみ出し | PASS | ローカルTopで横スクロールなしを確認 |

### Public verification

- `main`のコミット`7c67b28`反映後、公開Topで`main.css?v=20260912-faq-copy`の読み込みを確認
- 公開TopでFAQ見出し中央寄せ、4分類・11項目、会場住所、修正文、グッズ関連FAQなしを確認
- 公開Topで横スクロールなしを確認
- スマートフォン実機での表示確認は未実施

## Breakpoint and font-size calibration (2026-09-12)

### Scope

Top / Concept / Gallery / Contact Formのレスポンシブ境界と文字サイズを確認し、既存レイアウトを保ったまま切り替え条件を整理しました。

### Changes

- モバイルを`767px以下`、タブレットを`768px〜1199px`、デスクトップを`1200px以上`に統一
- TopのConcept / Artists、Galleryの旧`699px / 700px`境界を`767px / 768px`へ統一
- `375px / 376px / 480px / 481px / 1335px / 1336px`で分割していた本文スケールを、共通`clamp()`へ整理
- 共通本文を`14px〜16px`、h2を`20px〜30px`、h3を`16px〜22px`の範囲で画面幅に合わせて調整
- Galleryのカテゴリ見出し、紹介文、作品名・作者名も流動値へ調整
- 480px以下のHeaderなど、狭い画面専用の操作余白は維持
- 編集前コピーを`backups/20260912_before_breakpoint_font_review/`に保存
- CSSキャッシュバスターを`responsive-calibration`へ更新

### Local verification

| Check | Result | Evidence |
| --- | --- | --- |
| Top | PASS | 新キャッシュバスター、h2中央寄せ、FAQ11項目を確認 |
| Concept | PASS | h2 3件の中央寄せ、本文16px、横はみ出しなしを確認 |
| Gallery | PASS | h2 6件の中央寄せ、カテゴリ見出し約14.6px、本文約17.8px、横はみ出しなしを確認 |
| JavaScript | PASS | `faq.js`、`allmenu.js`、`gallery.js`、`slide.js`の構文確認 |
| Package | PASS | レビューZIPの整合性を確認 |

### Public verification

- `main`のコミット`6c49c2f`反映後、公開3ページで`responsive-calibration`の読み込みを確認
- 公開Topで本文16px、FAQ本文16px、h2約29.7px、FAQ見出し約21.7pxを確認
- 公開Conceptで本文16px、h2 3件の中央寄せを確認
- 公開Galleryでカテゴリ見出し15px、紹介文18px、作品情報16px、h2 6件の中央寄せを確認
- 公開3ページで横スクロールなしを確認
- スマートフォン実機での表示・タップ確認は未実施

## Concept horizontal text and liquid button update (2026-09-12)

### Changes

- ConceptページのFVに残っていた縦書き（`CONCEPT`ラベル、ロゴ、説明文）を横書きへ変更
- Conceptページ内の見出し、本文、説明ラベル、導線を中央寄せへ統一
- Conceptページ内のCTA「Galleryへ」をTopのViewと同じ`liquid-button`へ置換
- `liquid.css`と`liquid-button.js`をConceptページへ追加し、既存のGalleryリンクを維持
- Headerのハンバーガー操作ボタンは機能維持のため変更なし
- 編集前コピーを`backups/20260912_before_concept_horizontal_liquid_button/`に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Concept local | PASS | FV横書き、全体中央寄せ、`Galleryへ ↗`のカスタム要素を確認 |
| Concept public | PASS | `concept-horizontal-liquid-v1` URLで公開ページのFV、本文、導線を確認 |
| Liquid button | PASS | 公開AXツリーで`Galleryへ ↗`リンクを確認。Top Viewと同じ`liquid-button`を使用 |
| Existing content | PASS | 既存の文章、画像2点、共通Header／Footer、Galleryリンクを維持 |
| JavaScript / diff | PASS | `liquid-button.js`、`allmenu.js`構文と`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Concept feeling copy and Contact glass update (2026-09-12)

- Conceptページの「A MOMENT TO FEEL／感じるということ」セクションについて、ラベル・見出し・本文を左揃えに統一しました。
- Contactの送信ボタンに、TopのViewと同系統の液晶ガラス表現（半透明、ぼかし、反射、陰影、ホバー／フォーカス時の色変化）を明示的に適用しました。
- Concept／Contactのキャッシュバスターを更新し、公開環境で新しいCSSを確実に読み込むようにしました。
- 既存のフォーム項目、FAQ、共通ナビ、Concept／Galleryへのリンクは維持しました。
- 編集前コピーを`backups/20260912_before_concept-text-left-contact-glass/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Concept feeling copy alignment | PASS | ローカルおよび公開Conceptで対象セクションのラベル・見出し・本文を確認 |
| Contact submit glass effect | PASS | ローカルおよび公開TopのContact下部で半透明・ぼかし・反射を目視確認 |
| Existing Contact / FAQ structure | PASS | 公開Topのフォーム項目、送信ボタン、FAQ、共通ナビをAXツリーで確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Glass effect restore and arrow glyph update (2026-09-12)

### Changes

- ボタンの液晶ガラス効果（半透明、ぼかし、反射枠、陰影）を維持する構成へ戻しました。
- Top／Concept／Galleryの矢印付きCTAを`＞`表記へ統一しました。
- ホバー／キーボードフォーカス時の濃色化と矢印の右移動は維持しています。
- FAQ、問い合わせ、モーダル、Gallery絞り込み／ページ移動の既存機能を維持しました。
- `glass-arrow-v1`へキャッシュバスターを更新し、編集前コピーを保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Glass button styling | PASS | Top／Galleryで半透明背景、ぼかし、反射枠、陰影を確認 |
| Arrow glyph | PASS | `View ＞`、`Conceptを読む ＞`、`Galleryへ ＞`を確認 |
| Local behavior | PASS | Top／Concept／Gallery／FAQを確認 |
| Public pages | PASS | 公開Top／Concept／Galleryを`glass-arrow-v1-verify-20260912-r2`で確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Backup / review package | PASS | 編集前バックアップとレビュー資料を更新 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・ホバー／タップ確認は未実施 |

## Button background removal and hover update (2026-09-12)

### Changes

- 全ページの通常時ボタン背景とガラス効果を削除し、背景なしの状態へ統一
- Topの作品導線を`View →`へ変更
- ホバー／キーボードフォーカス時のみ背景色を表示し、文字色を反転
- 矢印付きCTAの矢印が右へ移動するアニメーションを追加
- Galleryの選択中ボタンは背景を使わず、枠線と文字の強調で状態を表示
- FAQ、問い合わせ、モーダル、Gallery絞り込み／ページ移動の既存機能を維持
- ハンバーガーボタンは専用メニュー構造のため変更対象外
- `button-hover-v1`へキャッシュバスターを更新し、編集前コピーを保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Source behavior | PASS | 通常時`background: transparent`、ホバー時背景色、矢印移動指定を確認 |
| Local Top | PASS | `View →`表示、作品導線、Concept導線を確認 |
| Local Concept / Gallery / FAQ | PASS | CTA、絞り込み、ページ移動、FAQボタンを確認 |
| Public pages | PASS | 公開Top／Concept／Galleryを`button-hover-v1-verify-20260912-r2`で確認 |
| Existing behavior | PASS | 共通ナビ、Galleryリンク、FAQの折りたたみ構造を確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Backup / review package | PASS | 編集前バックアップを保存し、レビュー資料を更新 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・ホバー／タップ確認は未実施 |

### Public addendum

- push後、公開TopのConcept導線と公開Galleryの絞り込みボタンを新しい液晶グラス表示で確認しました。
- 公開Top／Concept／Galleryのリンク、作品一覧、FAQ構造、共通ナビを確認しました。

## All content buttons liquid unification (2026-09-12)

### Changes

- TopのConcept導線をTopのViewと同じ`liquid-button`構成へ統一しました。
- Galleryの絞り込み・ページ移動、TopのFAQ・問い合わせ送信・モーダル操作を、Viewと同系統の液晶グラス表示へ統一しました。
- ネイティブ操作が必要なボタンは`button`要素と既存JSを維持し、共通の液晶グラスCSS／マウス反応を適用しました。
- ハンバーガーボタンは既存のメニュー開閉構造を維持するため対象外としました。
- 編集前コピーを`backups/20260912_before_all_buttons_liquid_unification/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Top | PASS | Concept導線とViewの`liquid-button`、FAQ・問い合わせ系ボタンを確認 |
| Concept | PASS | Gallery CTAの`liquid-button`と共通ナビを確認 |
| Gallery | PASS | 絞り込み・ページ移動の液晶グラス表示、作品一覧、共通ナビを確認 |
| Existing behavior | PASS | FAQ開閉、Galleryの初期作品表示、既存リンク構造を確認 |
| JavaScript | PASS | `liquid-button.js`、`gallery.js`、`faq.js`、`form.js`の構文確認 |
| Diff / package | PASS | `git diff --check`、レビューZIPの整合性、編集前バックアップを確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Concept FV label removal (2026-09-12)

### Changes

- ConceptページFV中央の「Concept」ラベルを削除しました。
- FVタイトル「ゆらゆら」とFV本文の縦書き、共通Header／Footer、FV以外の本文・CTAは維持しました。
- 編集前コピーを`backups/20260912_before_concept_fv_label_removal/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Source | PASS | FV内の`concept-fv__lead`要素を削除し、タイトル・本文を維持 |
| Local Concept | PASS | FV中央ラベルなし、タイトル・本文・共通ナビ・下層コンテンツを確認 |
| Public Concept | PASS | 公開URLでFV中央ラベルなし、縦書きFVと共通ナビを確認 |
| Diff / backup | PASS | `git diff --check`、編集前バックアップを確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Concept FV vertical restore (2026-09-12)

### Changes

- ConceptページのFVを縦書きへ戻しました。
- FV以外のConcept本文・見出し・CTAは、前回の横書き／中央寄せを維持しました。
- ConceptページのCSSキャッシュバスターを`concept-fv-vertical-v1`へ更新しました。
- 編集前コピーを`backups/20260912_before_concept_fv_vertical_restore/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Source direction | PASS | Concept FVの見出し・タイトル・本文を`vertical-rl`、FV以外を`horizontal-tb`で確認 |
| Local Concept | PASS | FVの縦書き表示、共通ナビ、FV以外の本文、Gallery CTAを確認 |
| Public Concept | PASS | 公開URLの安定表示でFVの縦書き、共通ナビ、Concept本文、Gallery CTAを確認 |
| JavaScript | PASS | `liquid-button.js`、`allmenu.js`の構文確認 |
| Diff / backup | PASS | `git diff --check`、編集前バックアップを確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Top Concept spacing update (2026-09-12)

### Changes

- TOPページのConcept見出しを本文ブロックに対して中央配置
- 見出しサイズ、行高、字間、見出し下の余白を画面幅に応じて調整
- 本文幅を最大680pxに制御し、行間をPC`1.9〜2.05`、スマホ`1.8〜1.95`の`clamp()`で調整
- 本文と見出しの中央揃えを維持し、Concept導線の余白も流動値へ調整
- 作品セクション、Conceptページ本体、Galleryは変更なし
- 編集前コピーを`backups/20260912_before_top_concept_spacing_update/`に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Active CSS target | PASS | 実際にTOPが読み込む`top-legacy.css`を修正。未使用の`top-sections.css`は変更前状態へ復元 |
| Local Top | PASS | Conceptの見出し、本文、導線、共通ナビ、後続セクションをローカルブラウザで確認 |
| Public Top | PASS | `top-concept-spacing-v2` URLで公開Topの本文、Concept導線、作品・FAQ・Accessを確認 |
| Concept / Gallery保全 | PASS | 公開Concept／Galleryのコンテンツとリンク構成を確認 |
| JavaScript | PASS | `allmenu.js`、`gallery.js`の構文確認。今回JS変更なし |
| Diff / backup | PASS | `git diff --check`、編集前バックアップ、レビューZIPを確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Body font-size range update (2026-09-12)

### Changes

- 本文を3段階の`clamp()`へ変更
  - モバイル：`12px〜14px`
  - タブレット：`13px〜15px`
  - デスクトップ：`14px〜16px`
- h2、h3、補助見出しも本文との比率を保った流動サイズへ調整
- Galleryのタイトル、カテゴリ、ページタイトル、ページャーも固定値を縮小・流動化
- 編集前コピーを`backups/20260912_before_body_font_scale_update/`に保存
- CSSキャッシュバスターを`font-scale-v2`へ更新

### Local verification

| Check | Result | Evidence |
| --- | --- | --- |
| Top | PASS | 本文15.1px、h2 29.3px、FAQ見出し18.2pxを確認 |
| Concept | PASS | 本文・h2の流動サイズと中央寄せを確認 |
| Gallery | PASS | カテゴリ、紹介文、作品情報の流動サイズを確認 |
| Existing behavior | PASS | FAQ11項目、h2中央寄せ、横はみ出しなしを確認 |
| JavaScript | PASS | 関連JavaScriptの構文確認 |

### Public verification

- `main`のコミット`b72deb2`反映後、公開3ページで`font-scale-v2`の読み込みを確認
- 公開Topで本文15.7px、FAQ本文15.7px、h2 31px、FAQ見出し19.3pxを確認
- 公開Conceptで本文15.7px、h2 3件の中央寄せを確認
- 公開Galleryでカテゴリ見出し15px、紹介文18px、作品情報15.7pxを確認
- 公開3ページで横スクロールなしを確認
- スマートフォン実機での表示・タップ確認は未実施

## Writing direction update (2026-09-12)

### Changes

- FV内のロゴ・説明文・Conceptラベル・Galleryの「作家紹介」を縦書きに統一
- Header／Footerの全メニューは既存どおり縦書きを維持
- FV以外のTop／Concept／Galleryの見出し、本文、FAQ、作品情報、ボタン類を横書きに統一
- Galleryに残っていたFV見出しの横書き強制指定を縦書きへ修正
- `writing-mode-v1`へキャッシュバスターを更新
- 編集前コピーを`backups/20260912_before_writing_mode_update/`に保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Writing direction source | PASS | FV／共通ナビの縦書き指定と、FV以外の横書き指定を確認 |
| Local Top / Concept / Gallery | PASS | 3ページのHTML、共通ナビ、本文、作品一覧をローカルブラウザで確認 |
| Public Top / Concept / Gallery | PASS | `writing-mode-v1` URLで3ページの公開表示、本文、作品、リンクを確認 |
| JavaScript | PASS | `allmenu.js`、`gallery.js`の構文確認。今回JS変更なし |
| Diff / backup | PASS | `git diff --check`、編集前バックアップを確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## FAQ flat surface and Contact glass correction (2026-09-12)

- Contact送信ボタンのガラス表現を明示的に維持し、無効状態でも効果が見えるよう透明度を調整しました。
- FAQのアコーディオン行を共通液晶ガラス処理の対象外にし、FAQ本来の平面表示へ戻しました。
- FAQの開閉処理、フォーム項目、共通ナビ、その他のCTAは維持しました。
- 編集前コピーを`backups/20260912_before_faq_glass_removal_send_glass_fix/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Contact submit glass | PASS | ローカルおよび公開TopのContact下部で半透明・ぼかし・反射を目視確認 |
| FAQ glass removal | PASS | ローカルおよび公開TopでFAQ行が平面表示になったことを確認 |
| FAQ behavior | PASS | FAQの開閉状態とアクセシブルなボタン構造を確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Contact cursor-position hover correction (2026-09-12)

- Contact送信ボタンのホバー背景を、他のガラスボタンと同じカーソル位置基準の放射グラデーションへ修正しました。
- `liquid-button.js`のポインター座標を利用し、ボタン上の位置に応じて濃淡が移動します。
- FAQアコーディオン行は引き続きガラス処理の対象外です。
- キャッシュバスターを`20260912-contact-faq-hover-v4`へ更新しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Contact hover gradient | PASS | カーソル位置変数を使うホバー背景をソースで確認し、公開Contact表示を確認 |
| FAQ flat surface | PASS | FAQボタンを共通ガラス処理から除外した状態をローカル／公開で確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Square arrow and extended Top Concept copy (2026-09-12)

- CTAの`＞`を正方形の枠内に配置し、ガラスボタンのホバー時の右移動を維持しました。
- TopのConceptセクションに、作品と空間の重なりや内側の変化を説明する3行を追加しました。
- `liquid-button.js`の共通表示に反映し、Top／Concept／Galleryのキャッシュバスターを更新しました。
- 編集前のHTML・JSコピーは既存バックアップを保持しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Square arrow | PASS | ローカルおよび公開Topで正方形枠内の`＞`を目視確認 |
| Top Concept copy | PASS | ローカルおよび公開TopのAXツリー・画面で追加文を確認 |
| Existing links / layout | PASS | Concept／Gallery導線、Contact、FAQ、共通ナビを確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## CSS chevron arrow correction (2026-09-12)

- `＞`の文字や外周の正方形枠ではなく、同じ幅・高さの正方形領域に右辺・下辺の2本のボーダーを描き、`rotate(-45deg)`で右向きシェブロンを作る方式へ修正しました。
- ホバー／フォーカス時は回転角を維持したまま右へ移動します。
- 矢印は装飾要素として`aria-hidden`にし、ボタンの読み上げ名に文字矢印を重複させません。
- 編集前コピーを`backups/20260912_before_css-chevron-arrow/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| CSS chevron construction | PASS | ローカルおよび公開Topで2辺ボーダー＋回転の右向き矢印を目視確認 |
| Top Concept copy | PASS | 公開Topで追加済みのConcept本文を確認 |
| Existing links / behavior | PASS | 共通ナビ、Concept／Gallery導線、Contact、FAQ構造を確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## FAQ content creation (2026-09-12)

- FAQ内の購入・発送・領収書カテゴリと、その質問・回答を削除しました。Contactフォームにある既存の問い合わせ種別「購入について」は今回のFAQ範囲外のため維持しています。
- 既存の展示期間・開催時間・会場アクセス・主催者情報を維持しました。
- 「展示について」と「お問い合わせ」を追加し、展示の趣旨、Galleryへの案内、問い合わせ方法を説明しました。
- FAQのHTML構造、アコーディオン開閉、既存のリンクとボタンを維持しました。
- 編集前コピーを`backups/20260912_before_faq_content_creation/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| FAQ content | PASS | ローカルおよび公開Topで新しい5カテゴリと追加回答を確認 |
| Purchase/goods FAQ removal | PASS | 公開TopのFAQに購入・支払い・発送・領収書のカテゴリ／質問がないことを確認 |
| FAQ accordion behavior | PASS | 追加した「どのような展示ですか？」を開き、`aria-expanded="true"`を確認 |
| Existing links and structure | PASS | Header／Footer、Concept／Gallery導線、Contactフォームを確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## FAQ answer wording and contact category removal (2026-09-12)

- FAQの回答を、日付・交通・駐車場・住所を含めて主語と説明を備えた文章へ統一しました。
- FAQ内の「お問い合わせ」カテゴリと、その質問・回答を削除しました。
- FAQ内の期間・アクセス・展示・主催者の4カテゴリ、Contactフォーム、既存リンクとアコーディオン構造は維持しました。
- 編集前コピーを`backups/20260912_before_faq_answer_expansion/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Explanatory FAQ answers | PASS | ローカルおよび公開TopのAXツリーで全回答を説明文として確認 |
| Contact FAQ category removal | PASS | 公開TopのFAQに「お問い合わせ」カテゴリと質問がないことを確認 |
| FAQ accordion behavior | PASS | 公開Topで「展示期間」を開き、`aria-expanded="true"`を確認 |
| Existing Contact / links | PASS | Contactフォーム、Concept／Gallery導線、共通Header／Footerを確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## FAQ answer font-size reduction (2026-09-12)

- FAQ回答（`.faq-sub-txt`）だけを、共通本文サイズから2px小さくしました。
- レスポンシブ幅を維持するため、`clamp(10px, calc(var(--responsive-copy-size) - 2px), 14px)`を使用しました。
- FAQの質問行、見出し、Contactフォーム、開閉構造は変更していません。
- Topの`main.css`キャッシュバスターを更新し、編集前コピーを`backups/20260912_before_faq_answer_font_size/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| FAQ answer font size | PASS | 公開Topで回答13.714px、質問行15.714pxを実測し、2px差を確認 |
| Responsive CSS | PASS | `.faq-sub-txt`に`clamp`と共通本文サイズからの`- 2px`を確認 |
| FAQ display / behavior | PASS | 公開Topで回答を開き、説明文と開閉状態を確認 |
| Existing structure | PASS | FAQ4カテゴリ、Contactフォーム、Concept／Gallery導線、共通Header／Footerを確認 |
| JavaScript / diff | PASS | `node --check`、`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Verified access information addition (2026-09-13)

- 公開されている会場アクセス案内を確認し、横浜市営バスの案内を追加しました。
- FAQの「アクセス（駐車場と最寄り駅）」に「横浜市営バスで行けますか？」を追加し、会場情報にも同じ交通手段を追加しました。
- 「元町」停留所から徒歩約2分、21・101・105・106系統、来場前に運行状況・時刻を確認する注意書きを反映しました。
- タクシー、駐輪場、バリアフリー、駐車料金・空き状況など、今回の検索で展示向けの十分な根拠を確認できなかった情報は追加していません。
- 編集前コピーを`backups/20260913_before_access_faq_addition/`に保存しました。

参照元： [CHARLOTTE.USAGIのアクセス案内](https://bizhorizon.sakura.ne.jp/charlotte.usagi/access/)

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Bus access content | PASS | 公開案内に基づく停留所・徒歩時間・4系統をFAQと会場情報へ反映 |
| FAQ accordion | PASS | ローカルおよび公開Topでバス質問を開き、`aria-expanded="true"`を確認 |
| Existing access / FAQ structure | PASS | 鉄道2項目・駐車場・住所、FAQ4カテゴリ、FAQ内の「お問い合わせ」カテゴリなしを確認 |
| Concept / Gallery impact | PASS | 公開Concept／Galleryのタイトル、本文、作品一覧、共通ナビを確認 |
| JavaScript / diff | PASS | `node --check assets/js/faq.js`、`git diff --check`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## FAQ emphasis and additional map guidance (2026-09-13)

- FAQ回答のうち、来場判断に直結する展示日、開催時間、駅・出口・徒歩時間、駐車場の空き状況、住所、バス停・系統、Gallery導線などを`<strong>`で太字化しました。
- FAQのアクセス欄に「地図や経路を確認できますか？」を追加し、ページ下部の会場情報の地図を案内しました。
- 会場の検索結果で確認できなかった入場料・予約、撮影可否、車いす・ベビーカー対応、混雑・滞在時間などは、今回の展示向けの確定情報がないため追加していません。
- 編集前コピーを`backups/20260913_before_faq_emphasis_and_map_question/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| FAQ emphasis | PASS | ローカルおよび公開Topで重要箇所を`<strong>`化し、公開ブラウザで計算フォントウェイト`700`を確認 |
| Map FAQ | PASS | ローカルおよび公開Topで「地図や経路を確認できますか？」を確認 |
| FAQ accordion | PASS | 公開Topで「展示期間」を開き、`aria-expanded="true"`を確認 |
| Existing content / structure | PASS | FAQ4カテゴリ、鉄道・駐車場・住所・バス案内、FAQ内の「お問い合わせ」カテゴリなしを確認 |
| Concept / Gallery impact | PASS | 公開Concept／Galleryのタイトル、本文、作品一覧、共通ナビを確認 |
| JavaScript / diff / package | PASS | `node --check`、`git diff --check`、`unzip -tq`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Page-navigation CTA margin unification and Top responsive refinement (2026-09-13)

- 「マージントップを統一するボタン」は、ページ遷移を行うCTAに限定しました。対象はTopの「Conceptを読む」「View」とConceptページのGallery遷移ボタンです。
- 送信ボタン、FAQアコーディオン、ハンバーガーメニュー、Galleryの絞り込み・作品操作など、ページ内操作のボタンは今回のマージン統一対象から除外しました。
- 共通の`--page-nav-button-margin-top`を追加し、デスクトップ／タブレットは`clamp(28px, 3.5vw, 40px)`、スマートフォンは`clamp(24px, 5.5vw, 32px)`で調整しました。既存のガラス効果・ボタン構造は維持しています。
- Topはタブレット幅（768〜1199px）でセクション高さ、左右余白、本文幅、作品カード、Viewボタンを流動調整し、スマートフォン幅では左右余白、カード高さ、CTA幅を画面幅に合わせるルールへ整理しました。
- 編集前の対象ファイルは`backups/20260913_before_button_margin_and_top_responsive/`へコピーして保管しています。公開反映コミットは`3a42f4f`です。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Page-navigation CTA margin | PASS | ローカル狭幅（CSS viewport 734px）でTopのConcept／Viewが32px、広幅（1280px）でConcept／View／Concept Galleryが40pxになることを確認 |
| Top narrow layout | PASS | ローカル狭幅でTopの左右余白・カード・CTAを確認し、`clientWidth`と`scrollWidth`が一致 |
| Top tablet rules | PASS | 768〜1199pxの専用メディアクエリ、流動余白・カード・CTA幅をソースと差分で確認。実機タブレット表示は未実施 |
| Public Top | PASS | 公開Topで新しいCSSキャッシュバスター、Concept／Viewの40px、横方向オーバーフローなしを確認 |
| Public Concept / Gallery | PASS | 公開ConceptのGallery遷移CTA（40px）、見出し・本文、公開Galleryのタイトル・4作品・共通ナビ、横方向オーバーフローなしを確認 |
| Existing interaction scope | PASS | 今回はページ遷移用CTAのCSSとTopのレスポンシブCSSのみを変更し、送信・FAQ・メニュー・Gallery操作のJS／構造を変更していないことを確認 |
| Diff / package | PASS | `git diff --check`および更新後の`unzip -tq`を確認 |
| Physical tablet / smartphone acceptance | NOT TESTED | 実機の表示・タップ、キーボード操作は未実施 |

## Opening hours exception update (2026-09-13)

- FAQの開催時間を、初日（10/06）は13:00から、最終日（10/12）は13:00まで、その他の日は11:30〜20:00として更新しました。
- 下部の会場情報も「通常日」「初日」「最終日」「LightUp」の4行に整理し、FAQと同じ時間案内に統一しました。
- 初日・最終日・通常日の時間は、既存方針どおり重要情報として太字を維持しました。LightUpは20:00〜21:00のままです。
- 編集前コピーを`backups/20260913_before_opening_hours_update/`に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| FAQ opening hours | PASS | 公開Topの「開催時間」を開き、初日・最終日・通常日の説明文を確認 |
| Venue information hours | PASS | 公開Topの会場情報で4行の営業時間表示を確認 |
| Emphasis / accordion | PASS | 時間4箇所の`<strong>`と、開いた状態の`aria-expanded="true"`を確認 |
| Existing content / structure | PASS | FAQ4カテゴリ、アクセス案内、FAQ内の「お問い合わせ」カテゴリなしを確認 |
| Concept / Gallery impact | PASS | 変更対象外であること、および既存の公開表示を確認 |
| JavaScript / diff / package | PASS | `node --check`、`git diff --check`、`unzip -tq`を確認 |
| Smartphone physical acceptance | NOT TESTED | 実機での表示・タップは未実施 |

## Mobile header/footer shared layout and mobile-first calibration (2026-09-13)

- Top・Concept・GalleryのHeader／Footerを、同じ共有パーツ・同じナビ順序（左から「トップ - TOP」「世界観 - CONCEPT」「作品 - GALLERY」）で表示する構成へ統一しました。
- Galleryに残っていた旧専用Footerを`#js-footer`へ置き換え、Top／Conceptと同じ動的Footerを使用するようにしました。Gallery固有の配色はページ側のCSSで維持しています。
- `assets/css/menu-style.css`の`max-width:767px`に、ナビ位置・リンク幅／高さ・文字サイズ・字間・線の高さ・Footer余白を`clamp()`で調整するモバイルファースト設定を追加しました。
- スマートフォンでは、先頭時に共通ナビを表示し、既存のスクロール収納後はハンバーガーへ切り替わる構成を維持しました。開いたメニューは画面内に収まるよう高さを調整しています。
- 編集前コピーを`backups/20260913_before_mobile_header_footer_unification/`に保存しました。公開反映コミットは`90bc9a8`です。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local smartphone layout | PASS | 375x667でTop・Concept・Galleryの共通Header／Footer、3リンクの順序、縦書き、横方向オーバーフローなしを確認 |
| Local desktop layout | PASS | 1280x720で3ページのHeader／Footerの幅・高さ・リンク間隔・順序を確認 |
| Public smartphone layout | PASS | 公開Topを375px幅で確認し、先頭ナビ、スクロール後の収納、Footer、横方向オーバーフローなしを確認 |
| Public desktop layout | PASS | 公開Top・Concept・Galleryで共通CSS、3リンク、Footer寸法、Gallery旧Footer不在を確認 |
| Hamburger interaction | PASS | 公開Topを375px幅で開閉し、`aria-expanded`、3項目の画面内配置、横幅一致を確認 |
| Source and package checks | PASS | `node --check assets/js/allmenu.js`、`git diff --check`、更新後のZIP検査を確認 |
| Physical smartphone/tablet acceptance | NOT TESTED | 実機の表示・タップ、各OSのフォントレンダリングは未実施 |

## Tablet header/footer smartphone-equivalent layout and spacing (2026-09-13)

- 提示画像の630px幅を含む481〜1199pxをタブレット帯として扱い、Top・Concept・Galleryの共通Header／Footerをスマートフォンと同じ縦書き3列構成へ揃えました。
- タブレット帯ではリンク幅44px、リンク高さは`clamp(220px, 29vw, 260px)`、ナビ間隔は`clamp(10px, 1.2vw, 14px)`とし、PC用の大きなリンク幅・字間へ戻らないようにしました。
- 画面端からの位置、Header／Footer内部の間隔、Footer上下の余白はスマートフォンより広めに`clamp()`で調整しました。ページ本文やConcept／Gallery固有のレイアウトは変更していません。
- Top／Conceptは`assets/css/main.css`、Galleryはページ固有CSSの後段にある`assets/css/gallery.css`で同じ値を適用し、Galleryの旧Footer構造は発生しない状態を維持しました。
- 3ページのCSSキャッシュバスターを`20260913-tablet-header-footer-v1`へ更新しました。
- 編集前コピーを`backups/20260913_before_tablet_header_footer_spacing/`へ保存しました。公開反映コミットは`4631a32`です。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local 630px tablet layout | PASS | Top・Concept・Galleryで縦書き3列、44px幅、Top位置約34.6px、Footer上下126px／63px、横方向オーバーフローなしを確認 |
| Local 768px / 1024px tablet layout | PASS | Topでスマートフォン相当の縦書き3列を維持し、リンク高さ222.7px／260px、外側余白が段階的に広がることを確認 |
| Local 375px smartphone regression | PASS | 375x667で既存の20px位置、44px幅、220px高さ、Footer上下78.75px／40pxを維持 |
| Local 1280px desktop regression | PASS | 1280x720で既存の58px幅、371.2px高さ、40px間隔、横方向オーバーフローなしを確認 |
| Public 630px Top / Concept / Gallery | PASS | 3ページで新CSSを読み込み、縦書き3列、Footer余白、横方向オーバーフローなしを確認。Gallery旧Footer数は0 |
| Public 630px hamburger | PASS | スクロール収納後に`aria-expanded="true"`、画面高898px内のメニュー、横幅一致を確認 |
| Public 768px / 1280px regression | PASS | 公開Topでタブレットの同構成、PCの既存構成、横方向オーバーフローなしを確認 |
| Concept / Gallery content impact | PASS | Concept本文・画像、Gallery見出し・4作品・共通Footerを確認 |
| Physical tablet / smartphone acceptance | NOT TESTED | 実機の表示・タップ、各OSのフォントレンダリングは未実施 |

## Tablet access layout matched to smartphone (2026-09-13)

### Scope

提示画像で確認された、タブレット幅のアクセスセクションだけを対象にしました。Header／Footer、Topの他セクション、Concept、Galleryの本文・画像・JavaScriptは変更していません。

### Implemented

- 481〜1199pxでは、アクセスの経路案内と住所・問合せ・営業時間をスマートフォンと同じ1列へ変更
- 地図はアクセス内側の幅100%に統一
- 住所・問合せ・営業時間はスマートフォンと同じ上下線の区切りに変更
- タブレットの内側余白と情報欄の最小高さは`clamp()`で広めに調整
- `index.html`、`concept.html`、`gallery.html`の`main.css`キャッシュバスターを更新
- 編集前コピーを`backups/20260913_before_access_tablet_mobile_layout/`に保存
- 公開反映コミットは`2986a7f`（`Match tablet access layout to mobile`）

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local tablet 630px / 768px / 1024px | PASS | 経路案内・情報リストが`display:block`、情報3件の同一x座標・縦方向配置を確認 |
| Local smartphone 375px regression | PASS | スマホの1列配置、既存の地図・情報欄、横方向オーバーフローなしを確認 |
| Local desktop 1280px regression | PASS | PCの3列情報欄と既存の地図幅を維持、横方向オーバーフローなしを確認 |
| Public Top tablet 630px / 768px / 1024px | PASS | 更新後`main.css?v=20260913-access-tablet-mobile-v1`を読み込み、情報3件の縦積みと横方向オーバーフローなしを確認 |
| Public Top smartphone / desktop regression | PASS | 公開375px／1280pxでスマホ1列・PC既存3列と横方向オーバーフローなしを確認 |
| Concept / Gallery impact | PASS | アクセス指定を`.section--access`内に限定し、Concept／Galleryのアクセス外DOMとページ固有CSS・JSを変更していないことを確認 |
| Diff / package | PASS | `git diff --check`と更新後のレビューZIP検査を確認 |
| Physical tablet / smartphone acceptance | NOT TESTED | 実機の表示・タップ、各OSのフォントレンダリングは未実施 |

### Judgment

タブレットのアクセス部分は、スマートフォンと同じ縦積み構成へ修正し、公開Topでも反映を確認しました。PC幅の既存構成は維持しています。実機確認は別途必要です。

## Menu label order and English scale (2026-09-13)

### Scope

常時表示のHeader／Footer、スクロール後に開くハンバーガーメニュー、Top・Concept・Galleryの全メニュー表示を対象にしました。既存のページ遷移先、線の区切り、共有部品の構成は維持しています。

### Implemented

- メニューをすべて「トップ - TOP」「世界観 - CONCEPT」「作品 - GALLERY」の順に統一しました。DOM上も日本語、区切り線、英語の順です。
- 日本語を上段、英語を下段に配置し、英語は同じ表示対象の日本語より3px小さくなるよう共通CSSで指定しました。
- `clamp()`と既存のスマートフォン／タブレット用サイズ変数を使い、375px・タブレット幅・PC幅で同じ関係を保つようにしました。
- `index.html`、`concept.html`、`gallery.html`の共通CSSキャッシュバスターを`20260913-menu-label-order-scale-v1`へ更新しました。
- 編集前コピーを`backups/20260913_before_menu_label_order_and_scale/`へ保存しました。公開反映コミットは`891c6ed`（`Unify menu label order and English scale`）です。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local all menu targets | PASS | 375／630／1024／1280pxでHeader・Footerの3リンクを確認。日本語→線→英語の順序、英語-3px、横方向オーバーフローなし |
| Public Top all widths | PASS | 公開Topの375／630／1024／1280pxで同じ順序と文字サイズ差を確認。計算値は日本語12〜15.12px、英語9〜12.12px |
| Public hamburger menu | PASS | 公開Topの630pxでスクロール収納後に開閉し、`aria-expanded="true"`、3リンクの順序、英語-3px、横方向オーバーフローなしを確認 |
| Public Concept / Gallery | PASS | 630pxで両ページのHeader・Footer各3リンク、順序、英語-3px、横方向オーバーフローなしを確認 |
| Source checks | PASS | `node --check assets/js/allmenu.js`、`git diff --check`を確認。今回JS本体は変更していません |
| Review package | PASS | レビュー資料と確認用ZIPを更新し、`unzip -tq`で検査 |
| Physical smartphone / tablet acceptance | NOT TESTED | 実機の表示・タップ、各OS・ブラウザのフォントレンダリングは未実施 |

## Menu Japanese-first labels, centered borders, and compact spacing (2026-09-13)

### Scope

常時表示のHeader／Footer、スクロール収納後に開くハンバーガーメニュー、Top・Concept・Galleryの共通メニューを対象にしました。ページ本文、画像、作品一覧、FAQ、Contactの内容は変更していません。

### Implemented

- 表示ラベルを左から「トップ - TOP」「世界観 - CONCEPT」「作　品 - GALLERY」に統一しました。
- 各リンクのDOM順を日本語、`.menu-border`、英語に統一し、装飾線を日本語と英語の間の中央位置へ配置しました。
- 日本語と英語の上下位置を共通値へ揃え、上段・下段の余白を少し詰めました。
- 既存要件の英語3px縮小は、共通CSSの`clamp()`に加えてスマートフォン／タブレット帯へ直接適用し、CSS変数の継承競合を防止しました。
- `allmenu.js`と3ページの共通CSS／JSキャッシュバスターをv5へ更新しました。
- 編集前コピーを`backups/20260913_before_menu_border_center_spacing/`、`backups/20260913_before_menu_label_scale_fix/`、`backups/20260913_before_menu_label_scale_cascade_fix/`、`backups/20260913_before_menu_label_scale_important_fix/`へ保存しました。
- 公開反映コミットは`86a62db`、`43d4a3d`、`8df6bed`、`65f4c5c`です。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local Top all widths | PASS | 375／630／1024／1280pxで、ラベル順、`作　品`、日本語→線→英語のDOM順、線の中央配置、英語3px、横方向オーバーフローなしを確認 |
| Public Top all widths | PASS（レイアウト） | 公開v5の375／630／1024／1280pxでラベル、中央配置、余白、画面内収まり、横方向オーバーフローなしを確認 |
| Public English scale | NOTE | 公開確認に使用したChromeプロファイルの最小フォントサイズが12pxのため、375／630／1024pxでは英語が12px未満へ縮小されず、実効差分は0／1.005／2.384px。1280pxでは3px差。ソースとローカル通常環境では3px差を確認 |
| Public hamburger menu | PASS | 630pxでスクロール収納後に開閉し、`aria-expanded="true"`、3リンクのラベル順、DOM順、横方向オーバーフローなしを確認 |
| Public Concept / Gallery | PASS | v5で両ページのHeader・Footer各3リンク、ラベル順、DOM順、本文・作品表示の継続、横方向オーバーフローなしを確認 |
| Source checks | PASS | `node --check assets/js/allmenu.js`、`git diff --check`を確認 |
| Physical smartphone / tablet acceptance | NOT TESTED | 実機の表示・タップ、各OS・ブラウザのフォントレンダリングは未実施 |

## Relative English menu sizing correction (2026-09-13)

### Correction

「英語を3pxにする」のではなく「日本語の現在サイズから3px下げる」という指定に合わせ、英語のサイズを固定した`clamp()`から`calc(var(--menu-label-jp-size) - 3px)`へ変更しました。スマートフォン／タブレット帯と通常表示の両方で、日本語サイズの現在値を基準にします。

- `assets/css/main.css`と`assets/css/menu-style.css`の英語サイズ指定を相対計算へ統一
- 既存の日本語サイズ、中央の`.menu-border`、ラベル順、余白、ページ本文は維持
- 3ページのキャッシュバスターと`allmenu.js`の共通部品バージョンをv6へ更新
- 編集前コピーを`backups/20260913_before_menu_label_relative_scale/`へ保存
- 公開反映コミットは`d11f7d3`です

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local relative sizing | PASS | 375／630／1024／1280pxで、各項目の英語計算値が日本語の現在値−3pxになることを確認 |
| Local menu layout | PASS | ラベル順、`作　品`、日本語→線→英語のDOM順、中央線、横方向オーバーフローなしを再確認 |
| Public v6 load | PASS | 3ページの共通CSS／JSがv6を読み込むことを確認 |
| Public responsive layout | PASS | 公開Topの375／630／1024／1280pxでラベル、中央線、余白、画面内収まり、横方向オーバーフローなしを確認 |
| Public effective font size | NOTE | 確認用Chromeプロファイルの最小フォントサイズ12pxにより、狭幅では3px差より下限が優先される。CSSの相対指定は読み込み済み |

## Menu English size range 10–12px (2026-09-13)

### Correction

最新指定に合わせ、英語メニュー文字を「日本語から3px下げる」相対指定ではなく、全端末共通で最小10px・最大12pxの`clamp()`へ変更しました。

- `assets/css/main.css`と`assets/css/menu-style.css`を`clamp(10px, calc(0.4vw + 8px), 12px)`へ統一
- スマートフォン／タブレットの直接指定も同じ共通変数を参照
- 日本語、`.menu-border`、ラベル順、余白、リンク先、本文、Concept／Galleryは維持
- キャッシュバスターと`allmenu.js`の共通部品バージョンをv7へ更新
- 編集前コピーを`backups/20260913_before_menu_label_min10_max12/`へ保存
- 公開反映コミットは`b7cdec8`です

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local English range | PASS | 375px=10px、630px=10.52px、1024px=12px、1280px=12px。全幅でmin10px/max12pxを確認 |
| Local menu layout | PASS | ラベル順、`作　品`、日本語→線→英語のDOM順、中央線、横方向オーバーフローなし |
| Public v7 load | PASS | 公開Top／Concept／Galleryがv7の共通CSS／JSを読み込むことを確認 |
| Public menu layout | PASS | 公開Topの375／630／1024／1280pxでラベル、中央線、余白、画面内収まり、横方向オーバーフローなし |
| Public hamburger menu | PASS | 公開Topの630pxで収納後に開閉し、`aria-expanded`、3リンクの順序、中央線、横方向オーバーフローなしを確認 |
| Public Concept / Gallery | PASS | 公開Concept／GalleryのHeader・Footer共通メニュー、本文・作品表示、横方向オーバーフローなしを確認 |
| Public effective font range | NOTE | 確認用Chromeプロファイルの最小フォントサイズが12pxのため、公開計算値は各幅12px。ソースとローカル通常環境ではmin10px/max12pxを確認 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、各OS／ブラウザ未実施 |

## iPhone SE menu left alignment (2026-09-13)

### Correction

SE幅（375px以下）でメニューが大きく見える要因になっていた、リンク幅内の中央配置を見直しました。日本語ラベル、区切り線、英語ラベルの左端を、メニュー上部のHeader／Footerテキストの左端に揃えています。

- SE幅だけ`.menu-small`、`.menu-border`、`.menu-en`を左寄せに変更
- メニュー項目のwidth／height、gap、文字サイズ、リンク先、タップ領域は変更なし
- 376px以上のスマートフォン、タブレット、PCは従来の中央配置を維持
- 3ページの共通CSSキャッシュバスターを`20260913-se-menu-align-v10`へ更新
- 編集前コピーを`backups/20260913_before_se_menu_left_alignment/`へ保存
- 公開反映コミットは`9630580`です

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local SE alignment | PASS | 375pxでHeaderテキスト、メニュー、各ラベル／線の左端が約19.99pxで一致 |
| Local responsive regression | PASS | 376／480／768／1280pxで従来の配置、width、gap、横方向オーバーフローなしを確認 |
| Public SE alignment | PASS | 公開Topのv10 CSSを読み込み、375pxで各ラベル／線の左端とHeaderテキストが約19.99pxで一致 |
| Public Concept / Gallery | PASS | 公開v10の375pxで共通メニュー、本文／作品表示、横方向オーバーフローなしを確認 |
| Backup / package | PASS | 編集前コピー、レビュー資料、確認用ZIPを更新し、ZIP検査を実施 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、各OS／ブラウザ未実施 |

## Smartphone menu spacing tightened (2026-09-13)

### Correction

画像で指定されたスマホ表示のメニューについて、項目間の余白だけを狭めました。タップ領域としての各リンクの`width`は維持し、PC／タブレットの配置やメニュー内容は変更していません。

- スマホ帯の`--site-nav-gap`を`clamp(8px, 2.667vw, 10px)`から`clamp(4px, 1.067vw, 6px)`へ変更
- `menu-style.css`のスマホ用フォールバックも同じ流動値へ統一
- Header／Footerと収納後ハンバーガーの項目間隔へ同じ値を適用
- 3ページの共通CSSキャッシュバスターを`20260913-menu-padding-v8`へ更新
- 編集前コピーを`backups/20260913_before_mobile_menu_spacing/`へ保存
- 公開反映コミットは`df3adc7`です

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local smartphone spacing | PASS | 320px=4px、375px=4.00125px、480px=5.1216px。メニュー幅は128px／139.976px／142.234pxへ縮小 |
| Local smartphone layout | PASS | ラベル順、中央線、リンク幅、横方向オーバーフローなしを確認 |
| Local hamburger menu | PASS | 375pxで収納後に開閉し、gap約4px、3リンク、横方向オーバーフローなしを確認 |
| Public v8 smartphone spacing | PASS | 公開Topの320／375／480pxでv8 CSS、縮小後のgap、ラベル順、横方向オーバーフローなしを確認 |
| Public hamburger menu | PASS | 公開Topの375pxで収納後に開閉し、gap約4px、3リンク、横方向オーバーフローなしを確認 |
| Public Concept / Gallery | PASS | 公開Concept／Galleryの375pxでv8 CSS、共通メニュー、本文・作品表示、横方向オーバーフローなしを確認 |
| Public desktop regression | PASS | 公開Topの1280pxで既存gap40pxと横方向オーバーフローなしを確認 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、各OS／ブラウザ未実施 |

## Smartphone menu width adjusted (2026-09-13)

### Correction

追加指定に合わせ、スマホ表示のメニュー項目幅（`width`）を狭めました。前回調整した項目間gapはそのままにし、タブレット／PCの幅、ラベル内容、中央線、リンク先は維持しています。

- スマホ帯の`--site-nav-link-width`を`clamp(40px, 11.733vw, 44px)`から`clamp(36px, 10.667vw, 40px)`へ変更
- 320pxでは36px、375px／480pxでは40pxになる流動値を採用
- 収納後ハンバーガーにも同じリンク幅を適用
- 3ページの共通CSSキャッシュバスターを`20260913-menu-width-v9`へ更新
- 編集前コピーを`backups/20260913_before_mobile_menu_width/`へ保存
- 公開反映コミットは`0d09f1b`です

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local smartphone width | PASS | 320px=36px、375px=40px、480px=40px。メニュー全体幅は116px／128px／130.234px |
| Local smartphone layout | PASS | gap4／4.00125／5.1216px、ラベル順、中央線、横方向オーバーフローなし |
| Local hamburger menu | PASS | 375pxで収納後に開閉し、リンク幅40px、gap約4px、横方向オーバーフローなし |
| Public v9 smartphone width | PASS | 公開Topの320／375／480pxでv9 CSS、width、gap、ラベル順、横方向オーバーフローなしを確認 |
| Public Concept / Gallery | PASS | 公開v9の375pxで共通メニュー、本文・作品表示、横方向オーバーフローなしを確認 |
| Public desktop regression | PASS | 公開v9の1280pxで既存リンク幅58px、gap40px、横方向オーバーフローなしを確認 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、各OS／ブラウザ未実施 |

## iPhone SE whole-li menu alignment correction (2026-09-13)

### Correction

前回のSE専用指定では子要素だけを左へ移動していたため、ボーダーだけが左へ寄って見える状態になっていました。子要素への個別移動を取り除き、375px以下では`ul > li`全体へ相対位置の左オフセットを適用しました。

- `.header-list > .header-item`と`.footer-list > .footer-item`へ`left: clamp(-10px, -2.667vw, -8px)`を適用
- 日本語ラベル、`.menu-border`、英語ラベルを同じ`li`グループとして移動し、相対関係を維持
- 文字サイズ、リンク幅・高さ、gap、タップ領域、リンク先は変更なし
- 376px以上ではSE専用ルールを適用せず、従来の配置を維持
- 3ページの共通CSSキャッシュバスターを`20260913-se-menu-li-align-v11`へ更新
- 編集前コピーを`backups/20260913_before_se_menu_li_left_alignment/`へ保存
- ソース反映コミットは`cbd6393`です

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local SE whole-li alignment | PASS | 375pxで各`li`が約10px左へ移動し、内部の日本語・ボーダー・英字も同じ量だけ移動。横方向オーバーフローなし |
| Local responsive regression | PASS | 320／375／376／480／768／1280pxを確認。376px以上は従来配置、全幅で横方向オーバーフローなし |
| Local Concept / Gallery | PASS | 375pxでv11 CSS、共通メニュー、見出し・本文・作品表示を確認。横方向オーバーフローなし |
| Public Top | PASS | 公開v11 CSSを読み込み、375pxで`li`全体の左移動、ラベル順、横方向オーバーフローなしを確認 |
| Public Concept / Gallery | PASS | 公開v11の375pxで共通メニュー、見出し・本文・作品表示、横方向オーバーフローなしを確認 |
| Backup / package | PASS | 編集前コピーを保存し、確認用ZIPを更新・検査した |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、各OS／ブラウザ未実施 |

## Menu link padding removed (2026-09-13)

### Correction

メニューの`width`に十分な余裕があるため、Header／Footerのリンク内側`padding`を削除しました。リンクの外形サイズは維持し、文字・ボーダー・英字の配置とSE専用の`li`全体移動は変更していません。

- `.header-link`と`.footer-link`の通常・スマホ用`padding`を`0`へ統一
- 不要になった`--site-nav-link-padding`変数を削除
- デスクトップのwidth58px、スマホのwidth`clamp(36px, 10.667vw, 40px)`、height、gap、タップ領域を維持
- 3ページの共通CSSキャッシュバスターを`20260913-se-menu-no-padding-v12`へ更新
- 編集前コピーを`backups/20260913_before_menu_link_padding_removal/`へ保存
- ソース反映コミットは`617e42e`です

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local SE | PASS | 375pxでpadding0px、リンクwidth40px・height220px、SEの`li`位置、ラベル・ボーダー、横方向オーバーフローなしを確認 |
| Local desktop regression | PASS | 1280pxでpadding0px、リンクwidth58px、height・配置、横方向オーバーフローなしを確認 |
| Local Concept / Gallery | PASS | 375pxでv12 CSS、padding0px、見出し・本文・作品表示、横方向オーバーフローなしを確認 |
| Public Top | PASS | 公開v12 CSSを読み込み、375pxでpadding0px、リンク外形とラベル配置を確認 |
| Public Concept / Gallery | PASS | 公開v12の375pxでpadding0px、共通メニュー、見出し・作品表示、横方向オーバーフローなしを確認 |
| Backup / package | PASS | 編集前コピーを保存し、確認用ZIPを更新・検査した |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、各OS／ブラウザ未実施 |

## All-device button typography and spacing (2026-09-14)

### Scope

「前端末」は「全端末」と解釈し、Top／Concept／Galleryのページ遷移CTA、Topの送信ボタン、Galleryの絞り込み・ページ移動ボタンを対象にしました。FAQの回答行やモーダル閉じるボタンの機能・平面表示は変更していません。

### Changes

- `assets/js/liquid-button.js` の共通CTAをモバイルファーストの`clamp()`で調整し、文字サイズ、上下左右の内側余白、最小高さ、ラベル間隔を画面幅に応じて補間
- CTAの矢印は従来どおり右辺・下辺の2本のボーダーを回転した正方形とし、CSSで幅・高さを`var(--button-font-size) - 4px`に統一
- `assets/css/liquid.css` の送信・絞り込み・ページ移動などのガラスボタンにも`clamp()`の文字サイズ・余白・高さを適用
- タブレット帯のHeader／Footerリンクにも`padding: 0`を適用し、前回のメニュー内側余白の残存を解消。リンクのwidth／height、gap、SE幅の`li`全体移動は維持
- 3ページの共通CSS／JSキャッシュバスターを`20260914-button-size-spacing-v13`、`...v6`、`...v7`へ更新
- 編集前コピーを`backups/20260914_before_button_size_spacing/`へ保存

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local CTA typography | PASS | 320／375／480／768／1024／1280pxで文字サイズと内側余白が`clamp()`により連続変化 |
| Local arrow size | PASS | 全幅で矢印の計算幅・高さがボタン文字サイズより4px小さいことを確認。375pxは13px／9px |
| Local native controls | PASS | 送信、Gallery絞り込み、Galleryページ移動の文字サイズ・余白・最小高さを確認 |
| Local menu regression | PASS | 320〜1280pxでHeaderリンクのpaddingが0px、横方向オーバーフローなし |
| Local Concept / Gallery | PASS | 新キャッシュバスター、見出し、本文、Concept CTA、Gallery表示を確認 |
| Public Top | PASS | 公開版の375pxでv13 CSS／JS、CTA 13px、矢印9px、差分4px、送信ボタン、padding0pxを確認 |
| Public Concept / Gallery | PASS | 公開版の375pxでCTA／Galleryコントロール、本文、作品表示、横方向オーバーフローなしを確認 |
| Public tablet | PASS | 公開版768pxでCTAの可変値、矢印差分約4px、メニューpadding0px、横方向オーバーフローなしを確認 |
| JavaScript／差分 | PASS | `node --check assets/js/liquid-button.js`、`node --check assets/js/allmenu.js`、`git diff --check` |
| Backup / package | PASS | 編集前コピーを保存し、レビュー資料と確認用ZIPを更新・`unzip -tq`検査 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

ボタンの文字サイズ・余白は全端末で`clamp()`により調整され、矢印は2辺ボーダーの正方形を保ったまま文字より4px小さくなっています。公開Top／Concept／Galleryとタブレット幅まで確認済みです。実機での最終受入だけが未確認です。

## MD button and arrow size correction (2026-09-14)

### Correction

指定に合わせ、ページ遷移CTAの`.md`文字サイズを`clamp(14px, calc(0.5vw + 12px), 16px)`へ変更しました。矢印は幅・高さを`clamp(10px, calc(0.5vw + 8px), 12px)`、右辺・下辺のボーダーを`1px`へ変更し、`.md`文字サイズとの差分4pxを維持しています。キャッシュバスターは`liquid-button.js`のv8へ更新しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local `.md` size | PASS | 320／375px=14px、480px=14.4px、768px=15.84px、1024／1280px=16px |
| Local arrow size | PASS | 320／375px=10px、480px=10.3984px、768px=11.8359px、1024／1280px=12px。各幅で差分約4px |
| Local arrow border | PASS | 右辺・下辺ともに計算値1px |
| Local / public regression | PASS | Local 320〜1280px、公開Top／Concept／Galleryの375pxで横方向オーバーフローなし。公開Topの768pxも確認 |
| Cache busting | PASS | 3ページで`20260914-arrow-md-size-v8`を読み込み |
| JavaScript／差分 | PASS | `node --check assets/js/liquid-button.js`、`git diff --check` |
| Backup / package | PASS | `backups/20260914_before_arrow_md_size/`を保存し、確認用ZIPを更新・`unzip -tq`検査 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

`.md`の文字サイズは14〜16px、矢印は10〜12px、ボーダーは1pxで公開版へ反映済みです。ページ遷移ボタンの「文字サイズより4px小さい矢印」も維持しています。

## Header menu right alignment and Concept mobile refinement (2026-09-14)

### Scope

- 共通Header／Footerメニューを右側へ移し、レスポンシブな右余白で右端に揃えました。通常表示のタイトル・開催期間は従来どおり左側に残しています。
- 60%スクロール後のハンバーガーボタンも右側から表示し、開いたメニューは従来どおり画面全体を覆う構成を維持しました。
- TopとConceptページのコンセプト本文は、文末の「。」単位で改行する構成にしました。
- Conceptページの`EXHIBITION STATEMENT`を通常の文書フローへ戻し、「〜 ゆらぎの間で 〜」との間隔を他の見出しと同じ`1.2rem`に統一しました。スマホ帯では本文幅と行間も調整しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local responsive layout | PASS | 375／768／1024／1440pxでメニューの右端配置、Conceptの見出し間隔約19.2px、横方向オーバーフローなしを確認 |
| Public mobile layout | PASS | 公開Top／Concept／Galleryの375pxでv14／Concept v2を読み込み、右端配置と横方向オーバーフローなしを確認 |
| Public tablet layout | PASS | 公開Top／Concept／Galleryの768pxで右端配置、Conceptの見出し間隔約19.2px、横方向オーバーフローなしを確認 |
| Menu interaction | PASS | 公開Topの375pxでスクロール後に`is-compact`とハンバーガー表示、クリック後に`is-compact is-open`・`aria-expanded=true`・全画面メニューを確認 |
| Shared-page regression | PASS | Concept／Galleryの共通メニュー、本文、作品一覧、Footerを確認 |
| JavaScript／差分 | PASS | `node --check assets/js/allmenu.js`、`git diff --check` |
| Backup | PASS | 編集前コピーを`backups/20260914_before_menu_right_concept_mobile/`へ保存 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

メニューは3ページ共通で右側へ揃い、公開版でもスマホ・タブレットの画面内に収まっています。Conceptの上部英文と見出しは重ならず、指定どおり文末の「。」で改行されています。ソース反映コミットは`2fde29d`です。

## Whole Header right-edge alignment (2026-09-14)

### Scope

- `.header`全体を`right: var(--site-header-menu-side); left: auto;`へ統一し、タイトル・開催期間・ナビゲーションを同じ右端基準にしました。
- Galleryではページ固有CSSが共通CSSより後に読み込まれるため、最後のスコープ付きルールで`.header`全体を同じ右端へ揃えました。
- 3ページの`main.css`キャッシュバスターを`20260914-header-whole-right-v15`、GalleryのCSSを`20260914-header-whole-right-v3`へ更新しました。
- 編集前のソースと既存レビュー資料は`backups/20260914_before_header_whole_right/`へ保存しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local Top | PASS | 375／768／1440pxで`.header`と`.header-txt`の右端をそれぞれ347.0078／717.7656／1345.6016pxで確認。横方向オーバーフローなし |
| Local Gallery | PASS | 375pxでタイトル・開催期間を含む`.header`全体の右端347.0078px、メニュー右端347.0078px。横方向オーバーフローなし |
| Public Top／Concept／Gallery tablet | PASS | 768pxで3ページとも`.header`・`.header-txt`・メニューの右端717.7656px、`scrollWidth=clientWidth=760px` |
| Public Top／Concept／Gallery mobile | PASS | 375pxで3ページとも右端347.0078px、`scrollWidth=clientWidth=367px` |
| Public Gallery cache refresh | PASS | 公開Galleryが`gallery.css?v=20260914-header-whole-right-v3`を読み込み、タイトル・開催期間を含む`.header`が右端へ移動 |
| Hamburger interaction | PASS | 公開Top 375pxで`scrollY=401`時に`is-compact`、クリック後に`is-compact is-open`・`aria-expanded=true`・全画面メニューを確認 |
| JavaScript／差分 | PASS | `node --check assets/js/allmenu.js`、`git diff --check` |
| Backup / package | PASS | `backups/20260914_before_header_whole_right/`を保存し、確認用ZIPを再作成・`unzip -tq`検査 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

Top／Concept／Galleryの常時表示`.header`は、タイトル・開催期間・ナビゲーションを含めて同じレスポンシブな右端へ揃いました。公開版でも375／768pxで画面内に収まり、既存のスクロール収納とハンバーガー開閉も維持しています。主な反映コミットは`53929f3`、`3157b3a`、`0ca14d0`です。

## Header and menu overlap correction (2026-09-15)

### Scope

- タイトル・開催期間の領域と縦書きメニューが同じ上端で重ならないよう、メニュー全体を`.header`テキスト領域の下へ配置しました。
- メニューの上端は、画面幅に応じたテキスト領域の高さと余白から`clamp()`で算出しています。右端位置は従来どおり`.header`・テキスト・メニューで統一しています。
- Gallery固有CSSにも同じメニュー上端を適用し、3ページで共通の構成にしました。キャッシュバスターは`main.css` v16、Gallery CSS v4です。
- 編集前のソースとレビュー資料は`backups/20260914_before_header_overlap_fix/`へ保存しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local all pages | PASS | Top／Concept／Galleryの375／768／1440pxで、ヘッダーテキストと各メニュー項目の矩形が重ならないことを確認 |
| Local right edge | PASS | 375／768／1440pxで`.header`・テキスト・メニューの右端が347.0078／717.7656／1345.6016pxで一致 |
| Local responsive gap | PASS | メニュー上端は375px=80.7422px、768px=108.2813px、1440px=129.5938px。テキスト下端より下に配置 |
| Public all pages | PASS | 公開Top／Concept／Galleryの375／768pxで重なりなし、`scrollWidth=clientWidth`、v16／v4読み込みを確認 |
| Public desktop | PASS | 公開Top 1280pxで重なりなし。メニュー上端118.3984px、横方向オーバーフローなし |
| Hamburger interaction | PASS | 公開Top 375pxで`scrollY=401`後に`is-compact`、クリック後に`is-compact is-open`・`aria-expanded=true`・全画面メニューを確認 |
| JavaScript／差分 | PASS | `node --check assets/js/allmenu.js`、`git diff --check` |
| Backup / package | PASS | `backups/20260914_before_header_overlap_fix/`を保存し、確認用ZIPを再作成・`unzip -tq`検査 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

`.header`とメニューの右端揃えを維持したまま、タイトル・開催期間と縦書きメニューの重なりを解消しました。メニューは各端末幅でテキスト領域の下へ移動し、公開版の3ページでも同じ構成になっています。反映コミットは`1906d7e`です。

## Header left alignment restoration (2026-09-15)

### Scope

- `.header`全体（タイトル・開催期間・ナビゲーション）を左端基準へ戻しました。
- `.header-list`は前回の重なり解消を維持し、タイトル・開催期間の下へ可変余白で配置しています。
- 収納時のハンバーガーも左側から表示するように揃えました。
- 3ページのキャッシュバスターを`main.css?v=20260915-header-left-v17`へ更新し、Galleryは`gallery.css?v=20260915-header-left-v5`へ更新しました。
- 編集前コピーは`backups/20260915_before_header_left/`に保存しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local all pages | PASS | Top／Concept／Galleryの375／768／1440pxでヘッダー・テキスト・メニューの左端一致、矩形の重なりなし、横方向オーバーフローなし |
| Local left edge | PASS | 375／768／1440pxで左端が19.9922／42.2344／86.3984pxで一致 |
| Public all pages | PASS | 公開Top／Concept／Galleryの375／768pxで左端一致、重なりなし、`scrollWidth=clientWidth`、v17／v5読み込み |
| Public desktop | PASS | 公開Top 1280pxで左端一致、重なりなし、横方向オーバーフローなし |
| Hamburger interaction | PASS | 公開Top 375pxで`scrollY=401`後に`is-compact`、クリック後に`is-compact is-open`・`aria-expanded=true`・全画面メニューを確認 |
| JavaScript／差分 | PASS | `node --check assets/js/allmenu.js`、`git diff --check` |
| Backup / package | PASS | `backups/20260915_before_header_left/`を保存し、確認用ZIPを再作成・`unzip -tq`検査済み |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

`.header`・タイトル／開催期間・メニューを左端基準へ戻し、前回の上下分離による重なり防止とハンバーガー開閉を維持しました。反映コミットは`4396005`です。

## Header menu right alignment (2026-09-15)

### Scope

- タイトル・開催期間を含む`.header`本体は左端基準のまま維持しました。
- ナビゲーションの`.header-list`だけを右端基準へ移動しました。
- 収納時のハンバーガーもメニュー側として右側へ揃えました。
- 3ページのキャッシュバスターを`main.css?v=20260915-menu-right-v18`へ更新し、Galleryは`gallery.css?v=20260915-menu-right-v6`へ更新しました。
- 編集前コピーは`backups/20260915_before_menu_right_only/`に保存しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local all pages | PASS | Top／Concept／Galleryの375／768／1280pxでヘッダー本体は左、メニューは右、矩形の重なりなし、横方向オーバーフローなし |
| Local responsive edges | PASS | 375／768／1280pxでヘッダー本体の左端が19.9922／42.2344／76.7969px、メニューの右端が347.0078／717.7656／1195.2031px |
| Public all pages | PASS | 公開Top／Concept／Galleryの375／768pxでヘッダー本体は左、メニューは右、重なりなし、`scrollWidth=clientWidth`、v18／v6読み込み |
| Public desktop | PASS | 公開Top 1280pxでヘッダー本体は左、メニューは右、重なりなし、横方向オーバーフローなし |
| Hamburger interaction | PASS | 公開Top 375pxで`scrollY=401`後に右側のハンバーガーを表示し、クリック後に`is-compact is-open`・`aria-expanded=true`・全画面メニューを確認 |
| JavaScript／差分 | PASS | `node --check assets/js/allmenu.js`、`git diff --check` |
| Backup / package | PASS | `backups/20260915_before_menu_right_only/`を保存し、確認用ZIPを再作成・`unzip -tq`検査済み |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

`.header`本体は左側に戻した状態を維持し、ナビゲーションメニューと収納時のハンバーガーだけを右側へ配置しました。前回の上下分離による重なり防止と全画面メニュー開閉も維持しています。反映コミットは`c3ca2b3`です。

## Access information equal desktop widths (2026-09-15)

### Scope

- アクセス直下の`住所`・`問合せ`・`営業時間`を対象に、デスクトップ幅では3項目を同じ比率で伸縮させました。
- 固定上限`228px`を解除し、`flex: 1 1 0`で親領域を均等に使用するようにしました。
- 既存のタブレット／スマホの縦積み（各項目width 100%）は維持しています。
- 3ページの`main.css`キャッシュバスターを`main.css?v=20260915-access-info-equal-v19`へ更新しました。
- 編集前コピーは`backups/20260915_before_access_info_equal_width/`に保存しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local desktop Access | PASS | ローカルTopのアクセス情報で、3項目の境界が等間隔になり、親領域いっぱいに広がることを目視確認 |
| Public desktop Access | PASS | 公開Topのアクセス情報で、住所・問合せ・営業時間の3列が均等幅で表示されることを目視確認 |
| Tablet / smartphone rule | PASS | `481px〜1199px`の既存縦積みルールと`max-width: 767px`の全幅ルールを変更していないことを確認 |
| Concept / Gallery impact | PASS | 公開Concept／Galleryを表示し、既存の本文・作品・共通メニューが表示されることを確認 |
| Cache / source diff | PASS | 3ページのv19参照、`git diff --check`を確認 |
| Backup / package | PASS | 編集前コピーを保存し、確認用ZIPを再作成・`unzip -tq`検査済み |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

アクセス直下の3項目だけをデスクトップ時に均等伸縮へ変更し、タブレット／スマホの縦積みとConcept／Galleryの共通表示は維持しました。反映コミットは`5fa4da7a1777241dd849326de19a6dae56321269`です。

## Header text persistence on scroll (2026-09-15)

### Scope

- スクロール収納のCSS対象を`.header-list`だけに限定しました。
- `.header-txt`（タイトル・開催期間）はスクロール後も表示・位置を維持します。
- `allmenu.js`の`is-compact`切り替え、右側ハンバーガー、全画面メニュー開閉は維持しました。
- 3ページのキャッシュバスターを`menu-style.css?v=20260915-header-text-persistent-v15`へ更新しました。
- 編集前コピーは`backups/20260915_before_header_text_persistent/`に保存しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local all pages | PASS | Top／Concept／Galleryの375／768pxで`scrollY=401`後も`.header-txt`が`opacity:1`・`visibility:visible`・`transform:none`、`.header-list`だけが収納状態。1280pxのレイアウトも確認 |
| Local desktop threshold | PASS | Top 1280pxで`scrollY=481`後も`.header-txt`を表示し、`.header-list`だけを収納 |
| Public all pages | PASS | 公開Top／Concept／Galleryの375／768pxで同じ状態、`scrollWidth=clientWidth`、v15読み込み |
| Public desktop threshold | PASS | 公開Top 1280pxで`scrollY=481`後も`.header-txt`が表示、`.header-list`が非表示、右側ハンバーガー表示、横方向オーバーフローなし |
| Hamburger interaction | PASS | 公開Top 375pxでスクロール収納後に右側ハンバーガーをクリックし、`is-compact is-open`・`aria-expanded=true`・全画面メニューを確認 |
| JavaScript／差分 | PASS | `node --check assets/js/allmenu.js`、`git diff --check` |
| Backup / package | PASS | `backups/20260915_before_header_text_persistent/`を保存し、確認用ZIPを再作成・`unzip -tq`検査済み |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

スクロール時に`.header`のタイトル・開催期間を収納対象から除外し、`.header-list`だけがスライドアウトする構成へ変更しました。既存のスクロール判定とハンバーガー開閉は維持しています。反映コミットは`20c9c75`です。

## Access width and menu top alignment correction (2026-09-15)

### Scope

- 前回のv19変更で表示条件から外れていたタブレット幅を含め、アクセス直下の`住所`・`問合せ`・`営業時間`の幅指定を明示しました。
- `1200px以上`では3項目を`flex: 1 1 0`で親領域いっぱいに均等配置し、固定上限`228px`を適用しない構成にしました。
- `481px〜1199px`ではスマホと同じ縦積みを明示し、各項目を`width: 100%`にしました。スマホ幅の既存全幅指定も維持しています。
- 右側メニューの`.header-list`を、左側にある`.header`本体と同じ`--site-header-menu-top`で開始するようにしました。左右の設置位置は変更していません。
- 3ページの`main.css`キャッシュバスターを`main.css?v=20260915-access-info-equal-menu-top-v20`へ更新しました。
- 編集前コピーは`backups/20260915_before_access_info_equal_and_menu_top/`に保存しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local desktop Access | PASS | ローカルTopで、住所・問合せ・営業時間の3列が同じ幅で親領域に収まることを目視確認 |
| Local header/menu top | PASS | ローカルTop上端で、左側タイトルと右側メニューの開始高さが揃うことを目視確認 |
| Public desktop Access | PASS | 公開Topで、3項目の境界が等間隔になっていることを目視確認 |
| Public Concept / Gallery | PASS | 公開Concept／Galleryを再読込し、本文・作品・共通メニューが表示されることを確認 |
| Tablet width rule | PASS | `481px〜1199px`で各アクセス情報を100%幅の縦積みにする後勝ちルールを確認 |
| Cache / source diff | PASS | 3ページのv20参照、`git diff --check`、関連JavaScriptの構文確認を実施 |
| Backup / package | PASS | 編集前コピーを保存し、最終レポート反映後の確認用ZIPを更新・検査済み |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、主要ブラウザ、キーボード操作は未実施 |

### Judgment

アクセス欄は端末幅に応じて、PCでは均等3列、タブレット／スマホでは各項目100%幅の縦積みになるよう修正しました。メニューの上端は`.header`と同じ基準へ統一し、Concept／Galleryの既存表示は維持しています。ソース反映コミットは`63aeb81267de7bb03ecd52a981c0afa956a45321`です。

## Access information natural line-wrap adjustment (2026-09-15)

### Scope

- デスクトップのアクセス欄の親幅を`740px`から`840px`へ広げ、住所・問合せ・営業時間の3列均等配置を維持しました。
- 営業時間の「最終日（10/12）：13:00まで」が最後の1文字だけ折り返されない幅に調整しました。
- `481px〜1199px`のタブレットとスマホは、既存どおり各アクセス情報を100%幅の縦積みにしています。
- `.header`と右側メニューの上端基準は変更せず、3ページの`main.css`キャッシュバスターを`main.css?v=20260915-access-info-width-v21`へ更新しました。
- 編集前コピーは`backups/20260915_before_access_info_text_width/`に保存しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Local desktop Access | PASS | ローカルTopで3列の境界が等間隔のまま、営業時間の「最終日（10/12）：13:00まで」が自然な1行で表示されることを確認 |
| Tablet / mobile rule | PASS | `481px〜1199px`の縦積みルールとスマホの全幅指定を確認 |
| Header / menu top | PASS | 既存の`.header`左側配置と右側メニューの上端基準を変更していないことを確認 |
| Concept / Gallery impact | PASS | 今回の表示幅ルールはTopの`#access`内に限定され、Concept／Galleryはキャッシュバスター更新のみであることを確認 |
| Cache / source diff | PASS | v21参照、`git diff --check`、ソース反映コミット`b073681548ec68697e31b7b97838dc91f661fff1`を確認 |
| Backup / package | PASS | 編集前コピーを保存し、最終レポート反映後に確認用ZIPを更新・検査 |
| Physical smartphone / tablet | NOT TESTED | 実機表示・タップ、Safari・Firefox・Edge、キーボード操作は未実施 |

### Judgment

アクセス欄のデスクトップ表示を必要な範囲だけ横へ広げ、均等3列と自然な改行を両立しました。タブレット／スマホの縦積み、ヘッダーとメニューの配置、Concept／Galleryの表示は維持しています。

## Section width 780px and mobile menu spacing adjustment (2026-09-15)

### Scope

- `.section--contact .section__inner`、`.section--faq .section__inner`、`.section--access .section__inner`の幅を`min(100%, 780px)`へ統一しました。
- 既存のアクセス欄デスクトップ用上書きも`780px`に揃え、3列均等配置を維持しました。
- 添付スクリーンショットのスマホ用メニュー項目間隔を、従来の`4〜6px`から`14〜16px`へ10px広げました。通常表示と収納後メニューの両方に適用しています。
- 3ページのキャッシュバスターを、`main.css?v=20260915-section-width-780-menu-gap-v22`および`menu-style.css?v=20260915-section-width-780-menu-gap-v16`へ更新しました。
- 編集前コピーは`backups/20260915_before_section_width_780_menu_gap/`に保存しています。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Section widths | PASS | ローカルTopでcontact／faq／accessの`.section__inner`実効幅が各780pxになることを確認 |
| Access columns | PASS | アクセス欄の住所・問合せ・営業時間が780px内で均等配置されることを確認 |
| Mobile menu spacing rule | PASS | スマホ帯のCSS変数を14〜16pxへ変更し、通常表示・収納後の両方が同じ変数を参照することを確認 |
| Header / menu layout | PASS | `.header`左側配置、右側メニュー、上端基準は変更していないことを確認 |
| Concept / Gallery impact | PASS | 共通幅とメニュー間隔の範囲以外の固有レイアウト・文言・リンクは変更していないことを確認 |
| Cache / source diff | PASS | v22／v16参照、`git diff --check`、ソースコミット`80c8be63ddf7fa8c60405da347f04562f0a02df6`を確認 |
| Backup / package | PASS | 編集前コピーを保存し、レポート反映後に確認用ZIPを更新・検査 |
| Public HTML / CSS delivery | PASS | GitHub `main`へのpush後、fresh公開IABでv22／v16を読み込み、734pxの公開レスポンシブ幅で3セクションが各638px（`min(100%, 780px)`の実効値）になることを確認 |
| Physical devices / major browsers / keyboard | NOT TESTED | 実機スマートフォン／タブレット、Safari・Firefox・Edge、キーボード操作は未実施 |

### Judgment

指定された3セクションの最大幅を780pxへ揃え、スマホ用メニューの項目間隔だけを10px拡張しました。`main`への公開反映とfresh公開Topの配信確認まで完了しています。実機・主要ブラウザ・キーボード操作は未確認です。

## Loading boundary correction (2026-09-17)

### Discover

- 対象は `https://mizukioyama.github.io/yurayura/` と `concept.html` の霧ローディングです。
- 公開HTMLの `fog-hole.css` / `fog-hole.js` は `main` の `152178b` と一致し、HTTP 200、`cache-control: max-age=600`、`last-modified` も確認しました。
- 公開Chrome描画では境界が見える場面もありましたが、実装は `#fog-scene::after` 疑似要素に依存しており、mask・`isolation`・`overflow`・固定配置が同一要素に重なっていました。

### Change

- `#fog-scene::after` を `#fog-boundary` 実DOM要素へ変更し、mask対象の `#fog-blur-layer` と霧質感レイヤーの上に `z-index: 3` で配置しました。
- JSは疑似要素用CSS変数ではなく、境界要素の幅・高さ・透明度を直接更新します。
- 円形の色境界（深いオリーブ色＋淡い外周＋柔らかい影）、既存のイージング、保持時間、拡大時間、フェード時間は維持しました。
- `index.html` と `concept.html` のCSS／JSキャッシュバスターを `20260917-visible-boundary-v5` に統一しました。
- 変更前の `index.html`、`concept.html`、`fog-hole.css`、`fog-hole.js` を `backups/20260917_before_loading_boundary_fix/` に保存しました。

### Verification

| Check | Result | Evidence |
| --- | --- | --- |
| JavaScript構文 | PASS | `node --check assets/js/fog-hole.js` |
| 差分空白 | PASS | `git diff --check` |
| DOM / CSS / JS参照 | PASS | `#fog-boundary` がTop／Concept／CSS／JSで一致し、旧疑似要素参照は残っていない |
| Chrome実描画 PC | PASS | ローカルHTTPをChromeで1280×900、700／1800／3600ms相当で表示し、色付き円形境界を確認 |
| Chrome実描画 Mobile | PASS | ローカルHTTPをChromeで390×844で表示し、境界の縮小・表示を確認 |
| 他レイアウト保全 | PASS | 変更対象はTop／ConceptのローディングDOM、fog CSS／JS、キャッシュバスターのみ |
| 公開ページ再読込後の修整確認 | PENDING | Push後にfresh公開ページを再読み込みして確認する |

### Judgment

実装、ローカルChrome確認、GitHub PagesへのPush、Push後の公開Top／Concept／モバイル幅のfresh Chrome再読み込み確認を完了しました。公開ページは `v5` と `#fog-boundary` を配信し、色付き円形境界が実表示されました。

### Public verification after push

- Commit: `420eef32b261494796291a17ccf7e24b817de776`
- Remote `main`: 同じコミットSHAを確認
- Public URL: `https://mizukioyama.github.io/yurayura/`
- Public Concept URL: `https://mizukioyama.github.io/yurayura/concept.html`
- Public assets: `20260917-visible-boundary-v5`、`#fog-boundary` を確認
- Chrome実描画: Top 1280×900、Concept 1280×900、Top 390×844で色付き円形境界を確認
- Cache: fresh queryで旧 `v4` ではなく新 `v5` のHTML／CSS／JSを確認
