# Known issues

## Existing validation notices

`tidy` のHTML4互換検査では、既存コードの `canvas`、`main`、`section`、`article` などのHTML5要素と、既存の `&display` 表記が警告・エラーとして出力されます。今回の変更による新規警告ではありません。

## Acceptance boundary

実機スマートフォンでのユーザー受入確認は未実施です。localhostのブラウザ検証では、対象セクションとフォーム文言の横書き・左寄せ・レスポンシブサイズ・横はみ出しを確認済みです。

320〜1440pxのブラウザ検証で、対象テキストの横書き・左寄せ・12〜14px・横はみ出しなしを確認済みです。

今回の作業ではファイル削除を行っていません。復元用コピーは `backups/` に保持しています。
