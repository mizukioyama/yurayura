# Known issues

## Existing validation notices

`tidy` のHTML4互換検査では、既存コードの `canvas`、`main`、`section`、`article` などのHTML5要素と、既存の `&display` 表記が警告・エラーとして出力されます。今回の変更による新規警告ではありません。

## Acceptance boundary

実機スマートフォンでのユーザー受入確認は未実施です。localhostのブラウザ検証では、対象セクションとフォーム文言の横書き・左寄せ・clampによるレスポンシブサイズ・横はみ出しを確認済みです。

320〜1440pxのブラウザ検証で、対象テキストの横書き・左寄せ・clamp計算値・横はみ出しなしを確認済みです。

スライドショーはローカルブラウザで、スマホ時に親セクションへ設定された左右44px paddingを相殺し、表示領域と1枚のカードをviewport幅に揃えました。320/375/390/480/768/1336/1440pxでleft 0・right viewport、bodyの横スクロールなし、内部トラックの無限ループ動作を確認済みです。

Artistsのカード上Mizukiボタン背景もカード幅100%、左右0に揃えました。Viewボタンは深緑背景の親`.section__btn`を画面幅100%にし、スマホ時は親セクションの左右paddingを相殺、paddingでhost・Shadow DOM内wrapperをスマホ最大280px、PC480〜520px程度に調整しました。Galleryの既存ボタンは変更していません。

フォームの問い合わせ種別チェックボックスは2列2段へ変更済みです。320px幅でも各項目が収まり、既存の`form.js`による選択・必須検証は維持しています。

FVを除く全sectionの左右Paddingは44pxです。FVは既存レイアウト維持のため左右0pxです。320px幅でも横スクロールは発生していません。

Q&Aの`.faq-box`内側paddingは0pxに変更し、Contact・Q&A・Accessの左右余白を統一しています。

FAQアコーディオンは`faq.js`で1項目ずつ開閉する仕様です。実機でのタップ確認は未実施です。

今回の作業ではファイル削除を行っていません。復元用コピーは `backups/` に保持しています。
