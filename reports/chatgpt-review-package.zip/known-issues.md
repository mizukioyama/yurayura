# Known issues

## Existing validation notices

`tidy` のHTML4互換検査では、既存コードの `canvas`、`main`、`section`、`article` などのHTML5要素と、既存の `&display` 表記が警告・エラーとして出力されます。今回の変更による新規警告ではありません。

## Acceptance boundary

実機スマートフォンでのユーザー受入確認は未実施です。今回の外部参照URLもネットワーク名前解決により取得できなかったため、リポジトリ内の`gallery.html`と`works-list.css`を基準に実装しています。

320〜1440pxのブラウザ検証で、対象テキストの横書き・左寄せ・clamp計算値・横はみ出しなしを確認済みです。

Artistsはスライドショーから画像付きギャラリーカードへ変更しました。旧スライダー用の`memberSlider`/`memberTrack`は対象HTMLにないため、`slide.js`は対象なしで終了します。Viewボタンの既存幅・背景ルールは維持しています。

フォームの問い合わせ種別チェックボックスは2列2段へ変更済みです。320px幅でも各項目が収まり、既存の`form.js`による選択・必須検証は維持しています。

FVを除く全sectionの左右Paddingは44pxです。FVは既存レイアウト維持のため左右0pxです。320px幅でも横スクロールは発生していません。

Q&Aの`.faq-box`内側paddingは0pxに変更し、Contact・Q&A・Accessの左右余白を統一しています。

FAQは外側の分類を通常見出し、回答内の詳細項目を`faq.js`で1項目ずつ開閉する仕様です。実機でのタップ確認は未実施です。

外側見出しの背景は元のFAQ質問と同じ背景画像・境界表現です。

FV以外の全sectionは内容量に応じた自然な高さ、FVは100vhです。

スマホ幅ではFV以外の上下paddingを72〜96pxのレスポンシブ値にしています。実機スマートフォンでの最終受入確認は未実施です。

Concept/Artistsは専用のclamp値で上下paddingをさらに縮小しています。Artistsの背景画像コンテナは非表示で、カード画像付きギャラリーを表示します。

Conceptは意図的に共通sectionより広い上下余白を設定し、展示コンセプトの静かな見せ方を優先しています。

`main.css`には`v=20260909-artists-gallery-layout`のキャッシュバスターを付けています。

Footerリンクは`footer-link`クラスへ分離し、Headerと同じ文字間隔を指定しています。

今回の作業ではファイル削除を行っていません。復元用コピーは `backups/` に保持しています。

作家紹介ページは`gallery.html`として追加しました。外部公開URLでの実機表示確認は未実施です。
