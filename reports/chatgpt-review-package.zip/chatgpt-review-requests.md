# ChatGPT review requests

## Review target

1. Concept、Artists、Contact、FAQ、Access、フォーム、ヘッダー／フッターの文字サイズとArtistsからgallery.htmlへのリンク、gallery.htmlのカテゴリ／作品レイアウトだけが変更されていること
2. 指定文の句読点・表記が保持されていること
3. 本文が12〜14px、h1/h2/h3等がそれぞれの範囲で `clamp()` になっていること
4. Artists以外のHTML本文、背景アニメーション、フォーム送信処理に変更がないこと。Artistsのスライドショー構造は維持すること
5. 参照リポジトリの`src/gallery.html` / `src/style/gallery.css` / `src/style/sidebar.css` / `src/public/gallery-sidebar.html`と照合して設計していること
6. ギャラリーが参照元と同じ1作品1行の`.work`レイアウトで、作家・ジャンルで絞り込め、作品数に応じてページ数を自動生成すること

## Review evidence

- Concept本文のブラウザDOMテキストは指定文と一致
- Concept内の `br` は11個、全て `class="pc-br"`
- 390x844で対象テキストの表示とページ横幅のはみ出しなし
- 320x568でもページ横幅のはみ出しなし
- 375/376/480/481/1335/1336pxの境界を確認
- 1440x900でも横書き・左寄せ・ページ横幅のはみ出しなし
- h1/h2/h3、小見出し、フォーム、ヘッダー／フッターの計算後サイズを確認
- indexのArtistsスライドショーが維持され、Mizukiカード4件とViewボタンが`https://mizukioyama.github.io/yurayura/gallery.html`へリンクすることを確認
- gallery.htmlは参照元と同じ`gallery-containt`、`content`、`.work`、`.work-img`の構造になっていることを確認
- gallery.htmlは作家・ジャンルのカテゴリを表示し、1作品1行の参照レイアウトと作品数連動のページネーションを持つことを確認
- 4枚の作品画像は既存の`assets/img/*.webp`をそのまま読み込むことを確認
- `gallery.html`が作家紹介ページとして取得でき、4作品の`.work`と4つのアンカーが存在することを確認
- `gallery.js`の`pageSize=10`とフィルタ後作品数によるページ数自動生成を確認
- 既存のスライダーIDと`slide.js`を維持し、無限スライドショーを変更していないことを確認
- Viewボタンの既存のfluid幅・背景ルールを変更していないことを確認
- フォームの問い合わせ種別4項目は320/390/699/700/1024pxで2列2段、HTML順序は展示・作品／購入・その他のままであることを確認
- `form.js`は変更せず、チェック状態取得・1つ以上必須の検証が維持されていることを確認
- `index.html`のフォームCSSにキャッシュバスターを付け、最新の2列2段CSSが読み込まれることを確認
- FVを除く全sectionの左右Paddingが320/390/700/1024pxで44px、FVは左右0pxで既存レイアウトを維持していることを確認
- Q&Aの内側余白を0pxにし、Contact・Q&A・Accessの左右余白が揃っていることを確認
- 外側の「期間と場所と時間」「アクセス」などは通常見出し、回答内の詳細項目はアコーディオンとして開閉し、同時に複数開かないことを確認。質問順は展示概要、アクセス、販売作品・グッズ、購入、主催者の順
- 外側の見出し背景が元のFAQ質問と同じ背景画像・境界表現であることを確認
- FV以外の全sectionが内容量に応じた自然な高さ、FVだけが100vhであることを確認
- スマホ幅のFV以外の上下余白が`clamp()`/`calc()`で72〜96pxに収まり、縦長化が抑えられていることを確認
- Concept/Artistsの上下余白が追加で縮小され、Artists背景画像だけが非表示で、カード画像・スライドショーが残っていることを確認
- Conceptのみ、展示の雰囲気に合わせて上下余白を共通sectionより広いレスポンシブ値に調整したことを確認
- `main.css?v=20260909-slider-external-gallery`のキャッシュバスターにより最新CSSが読み込まれることを確認
- Footerリンクの文字間隔がHeaderと同じPC`0.8rem`、スマホ`0.2rem`で読み込まれることを確認
- 表示時のJavaScript errorなし
- 参照リポジトリはGit経由で取得して上記ファイルを確認済み。公開URLでのブラウザ実機表示確認はレビュー時に実施する
