# ゆらゆら公式サイト CSS変数ガイド

## フォントサイズの調整

編集対象は `assets/css/user-settings.css` です。9elements Min-Max Calculatorで、

- Min viewport：375px
- Max viewport：1440px

を固定し、各変数の最小値と最大値を入力します。生成された線形補間式を、同じ `clamp(min, calc(intercept + slopevw), max)` の形で置き換えます。

例：本文を375pxで14px、1440pxで16pxにする場合

```css
--type-body-size: clamp(14px, calc(13.2958px + 0.1878vw), 16px);
```

既存CSSとの互換性のため、`--responsive-copy-size`、`--responsive-heading-2`、`--responsive-heading-3`、`--responsive-small-heading`、`--button-font-size` はsemantic variableのaliasとして残しています。

## 対象外

1pxの線、アイコン、矢印、装飾用固定値、Galleryの演出用タイトル・固定サブタイトルは、表示形状を保つため対象外です。

変更後はTop／Concept／Galleryを375／390／430／768／1024／1280／1440pxで確認し、改行、横overflow、Header／Footer、Galleryの絞り込みとmodalを確認します。
